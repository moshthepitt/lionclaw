mod common;
use common::*;
use std::{fmt::Write, process::Command, time::Instant};

fn normalization_workload(depth: usize) -> String {
    let mut numeral = "zero".to_string();
    let mut beta = "zero".to_string();
    for _ in 0..depth {
        numeral = format!("(app succ {numeral})");
        beta = format!("(app (ann (lam x x) (Pi (x : Nat) Nat)) {beta})");
    }

    let mut program = String::from(
        "(inductive Nat (params ()) (indices ()) (sort (Type 0))\n\
         (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))\n\
         (inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A)))\n\
         (sort (Type 0)) (constructors ((refl : (app (app (app Eq A) a) a)))))\n",
    );
    writeln!(program, "(check {beta} Nat)").unwrap();
    // Conversion must normalize a recursive iota chain all the way to zero.
    writeln!(
        program,
        "(check (app (app refl Nat)\
         (app (app (app (app Nat-rec (lam _ Nat)) zero)\
          (lam n (lam ih ih))) {numeral}))\
         (app (app (app Eq Nat)\
          (app (app (app (app Nat-rec (lam _ Nat)) zero)\
           (lam n (lam ih ih))) {numeral})) zero))"
    )
    .unwrap();
    program
}

#[test]
fn normalization_workload_finishes_under_ten_seconds() {
    // Input construction and Cargo's release compilation both happen before
    // this timer. At depth 700 this is twice the existing depth-350 workload.
    let input = source(&normalization_workload(700));
    let start = Instant::now();
    let output = Command::new(env!("CARGO_BIN_EXE_type-checker"))
        .arg(input)
        .output()
        .expect("failed to invoke the release checker");
    let elapsed = start.elapsed();

    assert!(
        output.status.success(),
        "checker failed after {elapsed:?}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stdout.is_empty(), "checker wrote to stdout");
    assert!(output.stderr.is_empty(), "checker wrote to stderr");
    assert!(
        elapsed.as_secs_f64() < 10.0,
        "checker execution took {elapsed:?}, exceeding 10 seconds"
    );
}
