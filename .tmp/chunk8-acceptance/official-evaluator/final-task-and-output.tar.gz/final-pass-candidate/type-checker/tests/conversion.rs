mod common;
use common::*;
#[test]
fn beta_delta_iota_and_eta() {
    let o = run(&[fixture("conversion-positive.sexp")]);
    assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr))
}
#[test]
fn unequal_normal_forms() {
    assert!(!run(&[fixture("conversion-negative.sexp")]).status.success())
}
