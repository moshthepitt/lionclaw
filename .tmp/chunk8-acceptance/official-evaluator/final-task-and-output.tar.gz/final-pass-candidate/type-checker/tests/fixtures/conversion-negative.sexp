(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))
(check zero (Pi (x : Nat) Nat))
