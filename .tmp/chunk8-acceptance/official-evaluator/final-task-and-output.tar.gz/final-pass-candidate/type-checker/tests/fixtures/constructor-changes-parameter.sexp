(inductive Flip
 (params ((A : (Type 0)) (B : (Type 0))))
 (indices ())
 (sort (Type 0))
 (constructors ((flip : (app (app Flip B) A)))))
