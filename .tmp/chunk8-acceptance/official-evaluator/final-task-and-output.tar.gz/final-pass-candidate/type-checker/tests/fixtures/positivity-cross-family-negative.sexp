(inductive Wrap (params ((A : (Type 0)))) (indices ()) (sort (Type 0))
 (constructors ((wrap : (Pi (value : A) (app Wrap A))))))

(inductive Bad (params ()) (indices ()) (sort (Type 0))
 (constructors ((bad : (Pi (nested : (app Wrap Bad)) Bad)))))
