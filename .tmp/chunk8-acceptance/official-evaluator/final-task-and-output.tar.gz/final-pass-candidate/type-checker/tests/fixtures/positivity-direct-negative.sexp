(inductive Bad (params ()) (indices ()) (sort (Type 0))
 (constructors
  ((bad : (Pi (consume : (Pi (x : Bad) (Type 0))) Bad)))))
