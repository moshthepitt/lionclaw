(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat))))

(def-poly id ((u))
 (Pi (A : (Type u)) (Pi (x : A) A))
 (lam A (lam x x)))
(check (app (app (inst id ((umax 0 0))) Nat) zero) Nat)
(check (app (app (inst id ((usuc 0))) (Type 0)) Nat) (Type 0))

; Valid for both u <= v and u > v because umax dominates u.
(def-poly lift-type ((u v))
 (Pi (A : (Type u)) (Type (umax u v)))
 (lam A A))
(check (app (inst lift-type (1 0)) (Type 0)) (Type 1))

(inductive-poly Box ((u))
 (params ((A : (Type u))))
 (indices ())
 (sort (Type u))
 (constructors
  ((box : (Pi (value : A) (app (inst Box (u)) A))))))

(check (inst box (0) Nat zero) (inst Box (0) Nat))

; Equality forces polymorphic recursor iota, not merely typing.
(inductive Eq
 (params ((A : (Type 0)) (a : A)))
 (indices ((b : A)))
 (sort (Type 0))
 (constructors ((refl : (app (app (app Eq A) a) a)))))

(def boxed-result
 (Pi (value : (inst Box (0) Nat)) Nat)
 (lam value
  (app
   (app
    (app
     (app (inst Box-rec ((umax 0 0) (umax 0 0))) Nat)
     (lam _ Nat))
    (lam x zero))
   value)))

(check
 (app (app refl Nat)
  (app boxed-result (inst box (0) Nat zero)))
 (app (app (app Eq Nat)
       (app boxed-result (inst box (0) Nat zero)))
      zero))
