; This body would be valid only under u <= v.  Independently bound levels have
; no such ordering, so the declaration itself must be rejected.
(def-poly unsound ((u v))
 (Pi (A : (Type u)) (Type v))
 (lam A A))
