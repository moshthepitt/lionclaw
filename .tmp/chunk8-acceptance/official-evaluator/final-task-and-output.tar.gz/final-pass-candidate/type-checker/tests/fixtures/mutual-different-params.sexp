(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))
(inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A))) (sort (Type 0))
 (constructors ((refl : (app (app (app Eq A) a) a)))))

; Left has a parameter; Right does not.  Motives and branches quantify each
; family's own telescope in the generalized mutual recursor.
(mutual
 (inductive Left (params ((A : (Type 0)))) (indices ()) (sort (Type 0))
  (constructors
   ((left-value : (Pi (value : A) (app Left A)))
    (left-from-right : (Pi (right : Right) (app Left A))))))
 (inductive Right (params ()) (indices ()) (sort (Type 0))
  (constructors
   ((right-base : Right)
    (right-from-left :
     (Pi (A : (Type 0)) (Pi (left : (app Left A)) Right)))))))

(check (app (app left-value Nat) zero) (app Left Nat))
(check right-base Right)

(def count-left (Pi (value : (app Left Nat)) Nat)
 (lam value
  (app
   (app
    (app
     (app
      (app
       (app
        (app
         (app Left-rec (lam A (lam _ Nat)))
         (lam _ Nat))
        (lam A (lam x zero)))
       (lam A (lam right (lam ih (app succ ih)))))
      zero)
     (lam A (lam left (lam ih (app succ ih)))))
    Nat)
   value)))

(def count-right (Pi (value : Right) Nat)
 (lam value
  (app
   (app
    (app
     (app
      (app
       (app
        (app Right-rec (lam A (lam _ Nat)))
        (lam _ Nat))
       (lam A (lam x zero)))
      (lam A (lam right (lam ih (app succ ih)))))
     zero)
    (lam A (lam left (lam ih (app succ ih)))))
   value)))

(check
 (app (app refl Nat) (app count-left (app (app left-from-right Nat) right-base)))
 (app (app (app Eq Nat)
       (app count-left (app (app left-from-right Nat) right-base)))
      (app succ zero)))

(check
 (app (app refl Nat)
  (app count-right
   (app (app right-from-left Nat) (app (app left-value Nat) zero))))
 (app (app (app Eq Nat)
       (app count-right
        (app (app right-from-left Nat) (app (app left-value Nat) zero))))
      (app succ zero)))
