(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat))))
(inductive Bad (params ()) (indices ()) (sort (Type 0))
 (constructors ((bad : Nat))))
