(inductive Bool (params ()) (indices ()) (sort (Type 0))
 (constructors ((true : Bool) (false : Bool))))
(check
 (app
  (app
   (app
    (app (inst Bool-rec (1)) (lam _ (Type 0)))
    Bool)
   Bool)
  true)
 (Type 1))
