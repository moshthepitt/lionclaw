(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat))))
(inductive Unit (params ()) (indices ()) (sort (Type 0))
 (constructors ((unit : Unit))))
(inductive Bool (params ()) (indices ()) (sort (Type 0))
 (constructors ((true : Bool) (false : Bool))))

; Singleton Type 0 may eliminate to Type 1.
(check
 (app
  (app
   (app (inst Unit-rec (1)) (lam _ (Type 0)))
   Nat)
  unit)
 (Type 1))

; Multiple constructors may eliminate within Type 0.
(check
 (app
  (app
   (app
    (app (inst Bool-rec (0)) (lam _ Nat))
    zero)
   zero)
  true)
 Nat)

; A multi-constructor family above Type 0 is unrestricted.
(inductive BigBool (params ()) (indices ()) (sort (Type 1))
 (constructors ((big-true : BigBool) (big-false : BigBool))))
(check
 (app
  (app
   (app
    (app (inst BigBool-rec (2)) (lam _ (Type 1)))
    (Type 0))
   (Type 0))
  big-true)
 (Type 2))
