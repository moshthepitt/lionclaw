(inductive Bad (params ()) (indices ()) (sort (Type 0))
 (constructors
  ((bad :
    (Pi (consume : (Pi (x : (Type 0)) (Pi (y : Bad) (Type 0)))) Bad)))))
