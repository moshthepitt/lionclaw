(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))
(inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A))) (sort (Type 0))
 (constructors ((refl : (app (app (app Eq A) a) a)))))

(inductive List (params ((A : (Type 0)))) (indices ()) (sort (Type 0))
 (constructors
  ((nil : (app List A))
   (cons : (Pi (x : A) (Pi (xs : (app List A)) (app List A)))))))

(check (app nil Nat) (app List Nat))
(check (app (app (app cons Nat) zero) (app nil Nat)) (app List Nat))

; Branch arguments precede all recursive hypotheses: x, xs, ih.
(def length (Pi (xs : (app List Nat)) Nat)
 (lam xs
  (app
   (app
    (app
     (app
      (app List-rec Nat)
      (lam _ Nat))
     zero)
    (lam x (lam xs (lam ih (app succ ih)))))
   xs)))

(check (app length (app nil Nat)) Nat)
(check
 (app length (app (app (app cons Nat) zero) (app nil Nat)))
 Nat)
(check
 (app (app refl Nat) (app length (app (app (app cons Nat) zero) (app nil Nat))))
 (app (app (app Eq Nat)
       (app length (app (app (app cons Nat) zero) (app nil Nat))))
      (app succ zero)))

(inductive Vec (params ((A : (Type 0)))) (indices ((n : Nat))) (sort (Type 0))
 (constructors
  ((vnil : (app (app Vec A) zero))
   (vcons :
    (Pi (n : Nat)
     (Pi (x : A)
      (Pi (xs : (app (app Vec A) n))
       (app (app Vec A) (app succ n)))))))))

(def vlength
 (Pi (n : Nat) (Pi (xs : (app (app Vec Nat) n)) Nat))
 (lam n (lam xs
  (app
   (app
    (app
     (app
      (app
       (app Vec-rec Nat)
       (lam n (lam _ Nat)))
      zero)
     (lam n (lam x (lam xs (lam ih (app succ ih))))))
    n)
   xs))))

; Indexed recursive iota substitutes the constructor's n into the IH call.
(check
 (app
  (app vlength (app succ zero))
  (app (app (app (app vcons Nat) zero) zero) (app vnil Nat)))
 Nat)
(check
 (app (app refl Nat)
  (app
   (app vlength (app succ zero))
   (app (app (app (app vcons Nat) zero) zero) (app vnil Nat))))
 (app (app (app Eq Nat)
       (app
        (app vlength (app succ zero))
        (app (app (app (app vcons Nat) zero) zero) (app vnil Nat))))
      (app succ zero)))
