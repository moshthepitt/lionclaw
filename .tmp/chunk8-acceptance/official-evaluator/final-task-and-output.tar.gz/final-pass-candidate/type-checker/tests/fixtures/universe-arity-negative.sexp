(def-poly id ((u)) (Pi (A : (Type u)) A) (lam A A))
(check (inst id (0 1)) (Pi (A : (Type 0)) A))
