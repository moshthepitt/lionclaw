(mutual
 (inductive Left (params ()) (indices ()) (sort (Type 0))
  (constructors ((left : (Pi (consume : (Pi (x : Right) (Type 0))) Left)))))
 (inductive Right (params ()) (indices ()) (sort (Type 0))
  (constructors ((right : Right)))))
