(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat))))
(inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A))) (sort (Type 0))
 (constructors ((refl : (app (app (app Eq A) a) a)))))

; W occurs only in the codomain of the constructor argument function.
(inductive W (params ()) (indices ()) (sort (Type 0))
 (constructors
  ((leaf : W)
   (sup : (Pi (children : (Pi (n : Nat) W)) W)))))

; The sup branch receives children, then a pointwise recursive hypothesis.
(def fold (Pi (w : W) Nat)
 (lam w
  (app
   (app
    (app
     (app W-rec (lam _ Nat))
     zero)
    (lam children (lam ih (app ih zero))))
   w)))

(check
 (app fold (app sup (ann (lam n leaf) (Pi (n : Nat) W))))
 Nat)
(check
 (app (app refl Nat)
  (app fold (app sup (ann (lam n leaf) (Pi (n : Nat) W)))))
 (app (app (app Eq Nat)
       (app fold (app sup (ann (lam n leaf) (Pi (n : Nat) W)))))
      zero))
