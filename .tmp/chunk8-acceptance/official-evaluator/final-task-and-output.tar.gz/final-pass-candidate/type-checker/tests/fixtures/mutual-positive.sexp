(inductive Nat (params ()) (indices ()) (sort (Type 0))
 (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))
(inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A))) (sort (Type 0))
 (constructors ((refl : (app (app (app Eq A) a) a)))))

(mutual
 (inductive Even (params ()) (indices ()) (sort (Type 0))
  (constructors
   ((even-zero : Even)
    (even-succ : (Pi (value : Odd) Even)))))
 (inductive Odd (params ()) (indices ()) (sort (Type 0))
  (constructors
   ((odd-succ : (Pi (value : Even) Odd))))))

(check even-zero Even)
(check (app odd-succ even-zero) Odd)
(check (app even-succ (app odd-succ even-zero)) Even)

; Each recursor takes both motives and every branch.  The Even step receives
; an Odd hypothesis produced by Odd-rec with the same motive/branch prefix.
(def count-even (Pi (value : Even) Nat)
 (lam value
  (app
   (app
    (app
     (app
      (app
       (app Even-rec (lam _ Nat))
       (lam _ Nat))
      zero)
     (lam odd (lam ih (app succ ih))))
    (lam even (lam ih (app succ ih))))
   value)))

(check
 (app (app refl Nat)
  (app count-even (app even-succ (app odd-succ even-zero))))
 (app (app (app Eq Nat)
       (app count-even (app even-succ (app odd-succ even-zero))))
      (app succ (app succ zero))))

; Shared parameters are prepended once to both mutual recursors.
(mutual
 (inductive Tree (params ((A : (Type 0)))) (indices ()) (sort (Type 0))
  (constructors
   ((leaf : (Pi (x : A) (app Tree A)))
    (node : (Pi (children : (app Forest A)) (app Tree A))))))
 (inductive Forest (params ((A : (Type 0)))) (indices ()) (sort (Type 0))
  (constructors
   ((empty : (app Forest A))
    (more :
     (Pi (tree : (app Tree A))
      (Pi (forest : (app Forest A)) (app Forest A))))))))

(check (app (app leaf Nat) zero) (app Tree Nat))
(def tree-size (Pi (tree : (app Tree Nat)) Nat)
 (lam tree
  (app
   (app
    (app
     (app
      (app
       (app
        (app
         (app Tree-rec Nat)
         (lam _ Nat))
        (lam _ Nat))
       (lam x zero))
      (lam children (lam ih ih)))
     zero)
    (lam tree (lam forest (lam tree-ih (lam forest-ih tree-ih)))))
   tree)))
(check (app tree-size (app (app leaf Nat) zero)) Nat)
