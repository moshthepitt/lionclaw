(mutual
 (inductive Left (params ()) (indices ()) (sort (Type 0))
  (constructors ((left : Right))))
 (inductive Right (params ()) (indices ()) (sort (Type 0))
  (constructors ((right : Right)))))
