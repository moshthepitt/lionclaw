(check (Type 0) (Type 0))
