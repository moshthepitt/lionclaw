(inductive Bad (params ()) (indices ()) (sort (Type 0))
 (constructors
  ((bad :
    (Pi (consume : (Pi (k : (Pi (x : Bad) (Type 0))) (Type 0))) Bad)))))
