(def-poly bad ((u)) (Type v) (Type u))
