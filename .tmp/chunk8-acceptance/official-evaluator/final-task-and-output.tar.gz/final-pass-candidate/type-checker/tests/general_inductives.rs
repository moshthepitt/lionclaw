mod common;
use common::*;

#[test]
fn declarations_constructors_recursors_hypotheses_and_iota() {
    let output = run(&[fixture("general-inductives-positive.sexp")]);
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stdout.is_empty());
}

#[test]
fn invalid_constructor_results_are_rejected() {
    for fixture_name in [
        "constructor-wrong-family.sexp",
        "constructor-changes-parameter.sexp",
    ] {
        let output = run(&[fixture(fixture_name)]);
        assert!(!output.status.success(), "accepted {fixture_name}");
        assert!(output.stdout.is_empty());
    }
}
