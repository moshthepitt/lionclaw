use std::{
    ffi::OsStr,
    fs,
    os::unix::fs::PermissionsExt,
    path::{Path, PathBuf},
    process::Command,
    sync::atomic::{AtomicU64, Ordering},
    time::{SystemTime, UNIX_EPOCH},
};

static NEXT_TEMP_ID: AtomicU64 = AtomicU64::new(0);

struct TempPackage(PathBuf);

impl TempPackage {
    fn new() -> Self {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock is before the Unix epoch")
            .as_nanos();
        let sequence = NEXT_TEMP_ID.fetch_add(1, Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!(
            "type-checker-packaging-{}-{nonce}-{sequence}",
            std::process::id()
        ));
        fs::create_dir(&path).expect("failed to create temporary package directory");
        Self(path)
    }
}

impl Drop for TempPackage {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn copy_tree(source: &Path, destination: &Path) {
    fs::create_dir_all(destination).expect("failed to create copied directory");
    for entry in fs::read_dir(source).expect("failed to read package directory") {
        let entry = entry.expect("failed to read package entry");
        let file_type = entry.file_type().expect("failed to inspect package entry");
        let copied_path = destination.join(entry.file_name());
        if file_type.is_dir() {
            copy_tree(&entry.path(), &copied_path);
        } else if file_type.is_file() {
            fs::copy(entry.path(), copied_path).expect("failed to copy package file");
        } else {
            panic!(
                "unexpected non-file package entry: {}",
                entry.path().display()
            );
        }
    }
}

fn assert_no_target_dir_override(package: &Path) {
    let cargo_config = package.join(".cargo");
    if !cargo_config.exists() {
        return;
    }

    for name in ["config", "config.toml"] {
        let path = cargo_config.join(name);
        if path.is_file() {
            let contents = fs::read_to_string(&path).expect("Cargo configuration is not UTF-8");
            assert!(
                !contents.lines().any(|line| {
                    line.split_once('#')
                        .map_or(line, |(configuration, _)| configuration)
                        .contains("target-dir")
                }),
                "product Cargo configuration overrides target-dir in {}",
                path.display()
            );
        }
    }
}

#[test]
fn fresh_release_build_uses_the_conventional_executable_path() {
    let source = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = TempPackage::new();
    let package = temporary.0.join("package");
    fs::create_dir(&package).expect("failed to create copied package");

    for name in ["Cargo.toml", "Cargo.lock"] {
        fs::copy(source.join(name), package.join(name)).expect("failed to copy Cargo metadata");
    }
    copy_tree(&source.join("src"), &package.join("src"));
    if source.join(".cargo").is_dir() {
        copy_tree(&source.join(".cargo"), &package.join(".cargo"));
    }

    assert_no_target_dir_override(&package);

    let cargo = std::env::var_os("CARGO").unwrap_or_else(|| OsStr::new("cargo").to_owned());
    let output = Command::new(cargo)
        .args(["build", "--release"])
        .current_dir(&package)
        .env_remove("CARGO_TARGET_DIR")
        .output()
        .expect("failed to run nested release build");
    assert!(
        output.status.success(),
        "nested release build failed:\nstdout:\n{}\nstderr:\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = package.join("target/release/type-checker");
    let metadata = fs::symlink_metadata(&binary).unwrap_or_else(|error| {
        panic!(
            "missing conventional-path binary {}: {error}",
            binary.display()
        )
    });
    assert!(
        metadata.file_type().is_file(),
        "release binary is not a regular file"
    );
    assert_ne!(
        metadata.permissions().mode() & 0o111,
        0,
        "release binary has no executable permission bit"
    );
}
