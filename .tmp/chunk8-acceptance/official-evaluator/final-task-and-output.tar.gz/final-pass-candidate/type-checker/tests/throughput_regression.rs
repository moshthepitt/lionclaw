mod common;
use common::*;
use std::fmt::Write;

fn normalization_workload(depth: usize) -> String {
    let mut numeral = "zero".to_string();
    for _ in 0..depth {
        numeral = format!("(app succ {numeral})");
    }
    let mut beta = "zero".to_string();
    for _ in 0..depth {
        beta = format!("(app (ann (lam x x) (Pi (x : Nat) Nat)) {beta})");
    }
    let mut source = String::from(
        "(inductive Nat (params ()) (indices ()) (sort (Type 0))\n\
         (constructors ((zero : Nat) (succ : (Pi (n : Nat) Nat)))))\n\
         (inductive Eq (params ((A : (Type 0)) (a : A))) (indices ((b : A)))\n\
         (sort (Type 0)) (constructors ((refl : (app (app (app Eq A) a) a)))))\n",
    );
    writeln!(source, "(check {beta} Nat)").unwrap();
    // This equality forces a linear chain of recursive iota computations.
    writeln!(
        source,
        "(check (app (app refl Nat)\
         (app (app (app (app Nat-rec (lam _ Nat)) zero)\
          (lam n (lam ih ih))) {numeral}))\
         (app (app (app Eq Nat)\
          (app (app (app (app Nat-rec (lam _ Nat)) zero)\
           (lam n (lam ih ih))) {numeral})) zero))"
    )
    .unwrap();
    source
}

#[test]
fn deterministic_normalization_inductive_mutual_and_poly_workload() {
    let generated = source(&normalization_workload(350));
    for paths in [
        vec![generated],
        vec![fixture("general-inductives-positive.sexp")],
        vec![fixture("mutual-positive.sexp")],
        vec![fixture("universe-poly-positive.sexp")],
    ] {
        let output = run(&paths);
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.stdout.is_empty());
    }
}
