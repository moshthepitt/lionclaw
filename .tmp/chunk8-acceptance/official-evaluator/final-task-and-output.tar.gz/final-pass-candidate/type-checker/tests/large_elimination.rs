mod common;
use common::*;

#[test]
fn singleton_large_and_multi_same_universe_elimination_are_accepted() {
    let output = run(&[fixture("large-elimination-positive.sexp")]);
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn multi_constructor_type_zero_large_elimination_is_rejected() {
    assert!(!run(&[fixture("large-elimination-negative.sexp")])
        .status
        .success());
}
