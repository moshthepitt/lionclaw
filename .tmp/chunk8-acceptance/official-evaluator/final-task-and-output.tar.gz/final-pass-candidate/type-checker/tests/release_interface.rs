mod common;
use common::*;
#[test]
fn one_and_many_files_and_quiet_stdout() {
    let a = fixture("core-positive.sexp");
    let b = source("(check (Type 0) (Type 1))");
    for ps in [&[a.clone()][..], &[a, b][..]] {
        let o = run(ps);
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
        assert!(o.stdout.is_empty())
    }
}
#[test]
fn malformed_and_ill_typed_fail() {
    for n in ["malformed.sexp", "core-negative.sexp"] {
        let o = run(&[fixture(n)]);
        assert_eq!(o.status.code(), Some(1));
        assert!(o.stdout.is_empty())
    }
}
#[test]
fn declarations_flow_in_command_and_file_order() {
    let a = source("(def A (Type 1) (Type 0))");
    let b = source("(check A (Type 1))");
    assert!(run(&[a.clone(), b.clone()]).status.success());
    assert!(!run(&[b, a]).status.success())
}

#[test]
fn identifier_grammar_is_enforced_in_every_name_position() {
    for text in [
        "(def 9bad (Type 1) (Type 0))",
        "(def good (Pi (9x : (Type 1)) (Type 1)) (lam x x))",
        "(check (ann (lam 9x 9x) (Pi (x : (Type 1)) (Type 1))) (Pi (x : (Type 1)) (Type 1)))",
        "(inductive 9Bad (params ()) (indices ()) (sort (Type 0)) (constructors ((ok : 9Bad))))",
        "(inductive Good (params ()) (indices ()) (sort (Type 0)) (constructors ((9bad : Good))))",
        "(check (inst 9bad (0)) (Type 0))",
    ] {
        let output = run(&[source(text)]);
        assert_eq!(output.status.code(), Some(1), "accepted {text}");
        assert!(output.stdout.is_empty());
    }
}
