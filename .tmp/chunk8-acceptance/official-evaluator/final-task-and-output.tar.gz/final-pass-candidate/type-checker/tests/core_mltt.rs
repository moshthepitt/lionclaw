mod common;
use common::*;
#[test]
fn core_positive() {
    let o = run(&[fixture("core-positive.sexp")]);
    assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr))
}
#[test]
fn core_negative() {
    assert!(!run(&[fixture("core-negative.sexp")]).status.success())
}
