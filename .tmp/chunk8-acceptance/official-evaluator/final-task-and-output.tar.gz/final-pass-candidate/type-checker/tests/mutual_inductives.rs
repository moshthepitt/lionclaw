mod common;
use common::*;

#[test]
fn simultaneous_visibility_cross_hypotheses_and_iota() {
    for name in ["mutual-positive.sexp", "mutual-different-params.sexp"] {
        let output = run(&[fixture(name)]);
        assert!(
            output.status.success(),
            "{name}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.stdout.is_empty());
    }
}

#[test]
fn invalid_mutual_blocks_are_rejected() {
    for name in ["mutual-negative.sexp", "mutual-wrong-result.sexp"] {
        let output = run(&[fixture(name)]);
        assert!(!output.status.success(), "accepted {name}");
    }
}
