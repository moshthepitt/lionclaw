mod common;
use common::*;

#[test]
fn strictly_positive_higher_order_recursion_is_accepted() {
    let output = run(&[fixture("positivity-positive.sexp")]);
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn negative_occurrences_are_rejected() {
    for fixture_name in [
        "positivity-direct-negative.sexp",
        "positivity-higher-order-negative.sexp",
        "positivity-nested-domain-negative.sexp",
        "positivity-cross-family-negative.sexp",
    ] {
        let output = run(&[fixture(fixture_name)]);
        assert!(!output.status.success(), "accepted {fixture_name}");
    }
}
