mod common;
use common::*;

#[test]
fn definitions_inductives_constructors_recursors_and_level_expressions() {
    let output = run(&[fixture("universe-poly-positive.sexp")]);
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn invalid_level_scope_and_arity_are_rejected() {
    for name in [
        "universe-level-scope-negative.sexp",
        "universe-arity-negative.sexp",
        "universe-ordering-negative.sexp",
    ] {
        assert!(!run(&[fixture(name)]).status.success(), "accepted {name}");
    }
}
