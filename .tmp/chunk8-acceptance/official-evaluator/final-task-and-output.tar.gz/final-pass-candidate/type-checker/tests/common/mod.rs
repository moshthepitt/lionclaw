#![allow(dead_code)]
use std::{
    fs,
    path::PathBuf,
    process::Command,
    sync::atomic::{AtomicUsize, Ordering},
};
static N: AtomicUsize = AtomicUsize::new(0);
pub fn fixture(name: &str) -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures")
        .join(name)
}
pub fn run(paths: &[PathBuf]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_type-checker"))
        .args(paths)
        .output()
        .unwrap()
}
pub fn source(s: &str) -> PathBuf {
    let p = std::env::temp_dir().join(format!(
        "type-checker-{}-{}.sexp",
        std::process::id(),
        N.fetch_add(1, Ordering::Relaxed)
    ));
    fs::write(&p, s).unwrap();
    p
}
