mod common;
use common::*;

fn assert_accepts(program: &str) {
    let output = run(&[source(program)]);
    assert!(
        output.status.success(),
        "checker rejected a valid program:\n{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stdout.is_empty(), "checker wrote to stdout");
}

fn assert_rejects(program: &str) {
    let output = run(&[source(program)]);
    assert!(
        !output.status.success(),
        "checker accepted an invalid program"
    );
    assert!(output.stdout.is_empty(), "checker wrote to stdout");
}

#[test]
fn bare_ordinary_recursor_infers_a_higher_motive_universe() {
    assert_accepts(
        r#"
        (inductive TypeWrapper
          (params ()) (indices ()) (sort (Type 1))
          (constructors
            ((wrap-type : (Pi (A : (Type 1)) TypeWrapper)))))
        (check
          (app
            (app
              (app TypeWrapper-rec (lam _ (Type 1)))
              (lam A (Type 0)))
            (app wrap-type (Type 0)))
          (Type 1))
        "#,
    );
}

#[test]
fn bare_recursor_infers_a_motive_universe_hidden_by_definitions() {
    assert_accepts(
        r#"
        (def Hidden (Type 101) (Type 100))
        (def Small Hidden (Type 99))
        (inductive HighWrapper
          (params ()) (indices ()) (sort (Type 101))
          (constructors
            ((high-wrap : (Pi (value : Hidden) HighWrapper)))))
        (check
          (app
            (app
              (app HighWrapper-rec (lam _ Hidden))
              (lam value Small))
            (app high-wrap Small))
          Hidden)
        "#,
    );
}

#[test]
fn type1_inductive_sort_family_constructor_recursor_and_iota() {
    assert_accepts(
        r#"
        (inductive BigUnit
          (params ()) (indices ()) (sort (Type 1))
          (constructors ((big-unit : BigUnit))))
        (check BigUnit (Type 1))
        (check big-unit BigUnit)
        (check
          (app (app (app (inst BigUnit-rec (1)) (lam _ BigUnit)) big-unit) big-unit)
          BigUnit)
        "#,
    );
}

#[test]
fn bare_unit_singleton_large_elimination() {
    assert_accepts(
        r#"
        (inductive Unit
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((unit : Unit))))
        (check
          (app (app (app Unit-rec (lam _ (Type 0))) Unit) unit)
          (Type 1))
        "#,
    );
}

#[test]
fn bare_indexed_equality_singleton_large_elimination() {
    assert_accepts(
        r#"
        (inductive Unit
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((unit : Unit))))
        (inductive Eq
          (params ((A : (Type 0)) (a : A)))
          (indices ((b : A)))
          (sort (Type 0))
          (constructors ((refl : (app (app (app Eq A) a) a)))))
        (check
          (app
            (app
              (app
                (app
                  (app
                    (app Eq-rec Unit)
                    unit)
                  (lam b (lam proof (Type 0))))
                Unit)
              unit)
            (app (app refl Unit) unit))
          (Type 1))
        "#,
    );
}

#[test]
fn universe_polymorphic_inductive_generated_constants_at_multiple_levels() {
    assert_accepts(
        r#"
        (inductive Unit
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((unit : Unit))))
        (inductive-poly Box ((u))
          (params ((A : (Type u)))) (indices ()) (sort (Type u))
          (constructors
            ((box : (Pi (value : A) (app (inst Box (u)) A))))))
        (check (inst Box (0)) (Pi (A : (Type 0)) (Type 0)))
        (check (inst Box (1)) (Pi (A : (Type 1)) (Type 1)))
        (check (inst box (0))
          (Pi (A : (Type 0)) (Pi (value : A) (app (inst Box (0)) A))))
        (check (inst box (1))
          (Pi (A : (Type 1)) (Pi (value : A) (app (inst Box (1)) A))))
        (check
          (app
            (app
              (app
                (app (inst Box-rec (0 0)) Unit)
                (lam _ Unit))
              (lam value value))
            (app (app (inst box (0)) Unit) unit))
          Unit)
        (check
          (app
            (app
              (app
                (app (inst Box-rec (1 1)) (Type 0))
                (lam _ (Type 0)))
              (lam value value))
            (app (app (inst box (1)) (Type 0)) Unit))
          (Type 1))
        "#,
    );
}

#[test]
fn polymorphic_inductive_self_reference_is_scoped_at_each_bound_level() {
    assert_accepts(
        r#"
        (inductive-poly PolyList ((u))
          (params ((A : (Type u)))) (indices ()) (sort (Type u))
          (constructors
            ((poly-nil : (app PolyList A))
             (poly-cons :
               (Pi (head : A)
                 (Pi (tail : (app PolyList A))
                   (app PolyList A)))))))
        (check (inst PolyList (0)) (Pi (A : (Type 0)) (Type 0)))
        (check (inst PolyList (1)) (Pi (A : (Type 1)) (Type 1)))
        (check (inst PolyList (2)) (Pi (A : (Type 2)) (Type 2)))
        (check (inst poly-cons (0))
          (Pi (A : (Type 0))
            (Pi (head : A)
              (Pi (tail : (app (inst PolyList (0)) A))
                (app (inst PolyList (0)) A)))))
        (check (inst poly-cons (1))
          (Pi (A : (Type 1))
            (Pi (head : A)
              (Pi (tail : (app (inst PolyList (1)) A))
                (app (inst PolyList (1)) A)))))
        (check (inst poly-cons (2))
          (Pi (A : (Type 2))
            (Pi (head : A)
              (Pi (tail : (app (inst PolyList (2)) A))
                (app (inst PolyList (2)) A)))))
        "#,
    );
}

#[test]
fn polymorphic_global_still_requires_instantiation_outside_its_declaration() {
    assert_rejects(
        r#"
        (inductive-poly PolyList ((u))
          (params ((A : (Type u)))) (indices ()) (sort (Type u))
          (constructors ((poly-nil : (app PolyList A)))))
        (check PolyList (Pi (A : (Type 0)) (Type 0)))
        "#,
    );
}

#[test]
fn dependent_let_inference_substitutes_single_and_nested_values() {
    assert_accepts(
        r#"
        (inductive Unit
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((unit : Unit))))
        (inductive Eq
          (params ((A : (Type 0)) (a : A)))
          (indices ((b : A))) (sort (Type 0))
          (constructors ((refl : (app (app (app Eq A) a) a)))))
        (check
          (let (x : Unit) unit (app (app refl Unit) x))
          (app (app (app Eq Unit) unit) unit))
        (check
          (let (x : Unit) unit
            (let (proof : (app (app (app Eq Unit) x) x))
              (app (app refl Unit) x)
              proof))
          (app (app (app Eq Unit) unit) unit))
        "#,
    );
}

#[test]
fn multi_constructor_type_zero_still_rejects_large_elimination_inline() {
    assert_rejects(
        r#"
        (inductive Bool
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((false : Bool) (true : Bool))))
        (check
          (app
            (app
              (app
                (app Bool-rec (lam _ (Type 0)))
                (Type 0))
              (Type 0))
            false)
          (Type 1))
        "#,
    );
}

#[test]
fn local_let_and_top_level_definition_transparency() {
    assert_accepts(
        r#"
        (inductive Unit
          (params ()) (indices ()) (sort (Type 0))
          (constructors ((unit : Unit))))
        (check (let (Alias : (Type 0)) Unit unit) Unit)
        (def Alias (Type 0) Unit)
        (def alias-value Alias unit)
        (check alias-value Unit)
        (def Alias2 (Type 0) Alias)
        (check alias-value Alias2)
        "#,
    );
}
