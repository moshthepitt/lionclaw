use std::{
    cell::RefCell,
    collections::{HashMap, HashSet},
    env, fs, process,
};

type Result<T> = std::result::Result<T, String>;

#[derive(Clone, Debug, PartialEq, Eq)]
enum Sexp {
    Atom(String),
    List(Vec<Sexp>),
}

fn sexps(input: &str) -> Result<Vec<Sexp>> {
    let mut toks = Vec::new();
    let b = input.as_bytes();
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b';' => {
                while i < b.len() && b[i] != b'\n' {
                    i += 1;
                }
            }
            b'(' | b')' => {
                toks.push((b[i] as char).to_string());
                i += 1;
            }
            c if c.is_ascii_whitespace() => i += 1,
            _ => {
                let s = i;
                while i < b.len()
                    && !b[i].is_ascii_whitespace()
                    && b[i] != b'('
                    && b[i] != b')'
                    && b[i] != b';'
                {
                    i += 1;
                }
                toks.push(input[s..i].to_owned());
            }
        }
    }
    fn one(ts: &[String], p: &mut usize) -> Result<Sexp> {
        let t = ts.get(*p).ok_or("unexpected end of input")?;
        *p += 1;
        if t == "(" {
            let mut v = Vec::new();
            while ts.get(*p).map(|x| x.as_str()) != Some(")") {
                v.push(one(ts, p)?);
            }
            *p += 1;
            Ok(Sexp::List(v))
        } else if t == ")" {
            Err("unexpected ')'".into())
        } else {
            Ok(Sexp::Atom(t.clone()))
        }
    }
    let mut p = 0;
    let mut out = Vec::new();
    while p < toks.len() {
        out.push(one(&toks, &mut p)?)
    }
    Ok(out)
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
struct Nat(String);
impl Nat {
    fn parse(s: &str) -> Self {
        let s = s.trim_start_matches('0');
        Self(if s.is_empty() { "0".into() } else { s.into() })
    }
    fn suc(&self) -> Self {
        let mut b = self.0.as_bytes().to_vec();
        let mut i = b.len();
        loop {
            if i == 0 {
                b.insert(0, b'1');
                break;
            }
            i -= 1;
            if b[i] < b'9' {
                b[i] += 1;
                break;
            } else {
                b[i] = b'0'
            }
        }
        Self(String::from_utf8(b).unwrap())
    }
    fn max(self, o: Self) -> Self {
        if self.0.len() > o.0.len() || (self.0.len() == o.0.len() && self.0 >= o.0) {
            self
        } else {
            o
        }
    }
    fn le(&self, o: &Self) -> bool {
        self.0.len() < o.0.len() || (self.0.len() == o.0.len() && self.0 <= o.0)
    }
}
impl From<usize> for Nat {
    fn from(x: usize) -> Self {
        Self(x.to_string())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
enum Level {
    Nat(Nat),
    Var(String),
    Max(Box<Level>, Box<Level>),
    Suc(Box<Level>),
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
enum Term {
    Var(String),
    Type(Level),
    Pi(String, Box<Term>, Box<Term>),
    Sigma(String, Box<Term>, Box<Term>),
    Lam(String, Box<Term>),
    App(Box<Term>, Box<Term>),
    Pair(Box<Term>, Box<Term>),
    Fst(Box<Term>),
    Snd(Box<Term>),
    Let(String, Box<Term>, Box<Term>, Box<Term>),
    Ann(Box<Term>, Box<Term>),
    Inst(String, Vec<Level>),
}

fn atom(s: &Sexp) -> Result<&str> {
    if let Sexp::Atom(x) = s {
        Ok(x)
    } else {
        Err("expected atom".into())
    }
}
fn identifier(s: &Sexp) -> Result<&str> {
    let name = atom(s)?;
    if valid_id(name) {
        Ok(name)
    } else {
        Err(format!("invalid identifier '{name}'"))
    }
}
fn level(s: &Sexp) -> Result<Level> {
    match s {
        Sexp::Atom(x) if x.bytes().all(|c| c.is_ascii_digit()) => Ok(Level::Nat(Nat::parse(x))),
        Sexp::Atom(x) if valid_id(x) => Ok(Level::Var(x.clone())),
        Sexp::List(v) if v.len() == 3 && atom(&v[0])? == "umax" => {
            Ok(Level::Max(Box::new(level(&v[1])?), Box::new(level(&v[2])?)))
        }
        Sexp::List(v) if v.len() == 2 && atom(&v[0])? == "usuc" => {
            Ok(Level::Suc(Box::new(level(&v[1])?)))
        }
        _ => Err("invalid universe level".into()),
    }
}
fn valid_id(x: &str) -> bool {
    !x.is_empty()
        && !x.as_bytes()[0].is_ascii_digit()
        && x.bytes()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, b'-' | b'_' | b'\''))
}
fn binder(s: &Sexp) -> Result<(String, Term)> {
    let v = if let Sexp::List(v) = s {
        v
    } else {
        return Err("expected binder".into());
    };
    if v.len() != 3 || atom(&v[1])? != ":" {
        return Err("invalid binder".into());
    }
    Ok((identifier(&v[0])?.into(), term(&v[2])?))
}
fn term(s: &Sexp) -> Result<Term> {
    match s {
        Sexp::Atom(x) if valid_id(x) => Ok(Term::Var(x.clone())),
        Sexp::Atom(_) => Err("invalid identifier".into()),
        Sexp::List(v) => {
            if v.is_empty() {
                return Err("empty term".into());
            }
            let h = atom(&v[0])?;
            match (h, v.len()) {
                ("Type", 2) => Ok(Term::Type(level(&v[1])?)),
                ("Pi", 3) | ("Sigma", 3) => {
                    let (n, a) = binder(&v[1])?;
                    let b = term(&v[2])?;
                    if h == "Pi" {
                        Ok(Term::Pi(n, Box::new(a), Box::new(b)))
                    } else {
                        Ok(Term::Sigma(n, Box::new(a), Box::new(b)))
                    }
                }
                ("lam", 3) => Ok(Term::Lam(identifier(&v[1])?.into(), Box::new(term(&v[2])?))),
                ("app", 3) => Ok(Term::App(Box::new(term(&v[1])?), Box::new(term(&v[2])?))),
                ("pair", 3) => Ok(Term::Pair(Box::new(term(&v[1])?), Box::new(term(&v[2])?))),
                ("fst", 2) => Ok(Term::Fst(Box::new(term(&v[1])?))),
                ("snd", 2) => Ok(Term::Snd(Box::new(term(&v[1])?))),
                ("ann", 3) => Ok(Term::Ann(Box::new(term(&v[1])?), Box::new(term(&v[2])?))),
                ("let", 4) => {
                    let (n, a) = binder(&v[1])?;
                    Ok(Term::Let(
                        n,
                        Box::new(a),
                        Box::new(term(&v[2])?),
                        Box::new(term(&v[3])?),
                    ))
                }
                ("inst", n) if n >= 3 => {
                    let xs = if let Sexp::List(xs) = &v[2] {
                        xs
                    } else {
                        return Err("expected level list".into());
                    };
                    let instantiated = Term::Inst(
                        identifier(&v[1])?.into(),
                        xs.iter().map(level).collect::<Result<_>>()?,
                    );
                    Ok(v[3..].iter().try_fold(instantiated, |f, a| {
                        Ok::<_, String>(Term::App(Box::new(f), Box::new(term(a)?)))
                    })?)
                }
                _ => Err(format!("invalid term form '{h}'")),
            }
        }
    }
}

#[derive(Clone)]
struct Global {
    ty: Term,
    val: Option<Term>,
    levels: Vec<String>,
}
#[derive(Clone)]
struct CtorInfo {
    owner: String,
    fields: Vec<(String, Term)>,
}
#[derive(Clone)]
struct RecInfo {
    outer_params: usize,
    target_params: usize,
    generalized_params: bool,
    indices: usize,
    ctors: Vec<String>,
    motives: Vec<String>,
    family_params: HashMap<String, usize>,
    sort: Level,
}
struct Env {
    globals: HashMap<String, Global>,
    ctors: HashMap<String, CtorInfo>,
    recs: HashMap<String, RecInfo>,
    whnf_cache: RefCell<HashMap<Term, Term>>,
}
impl Default for Env {
    fn default() -> Self {
        Self {
            globals: HashMap::new(),
            ctors: HashMap::new(),
            recs: HashMap::new(),
            whnf_cache: RefCell::new(HashMap::new()),
        }
    }
}
#[derive(Clone)]
struct Local {
    name: String,
    ty: Term,
    val: Option<Term>,
}
type Ctx = Vec<Local>;

fn eval_level(l: &Level, ls: &HashMap<String, Nat>) -> Result<Nat> {
    match l {
        Level::Nat(n) => Ok(n.clone()),
        Level::Var(x) => ls
            .get(x)
            .cloned()
            .ok_or_else(|| format!("unbound universe level {x}")),
        Level::Max(a, b) => Ok(eval_level(a, ls)?.max(eval_level(b, ls)?)),
        Level::Suc(a) => Ok(eval_level(a, ls)?.suc()),
    }
}
fn scan_level_bound(level: &Level, largest: &mut Nat, nodes: &mut usize) {
    *nodes += 1;
    match level {
        Level::Nat(value) => *largest = largest.clone().max(value.clone()),
        Level::Var(_) => {}
        Level::Max(left, right) => {
            scan_level_bound(left, largest, nodes);
            scan_level_bound(right, largest, nodes);
        }
        Level::Suc(inner) => scan_level_bound(inner, largest, nodes),
    }
}
fn scan_term_level_bound(term: &Term, largest: &mut Nat, nodes: &mut usize) {
    *nodes += 1;
    match term {
        Term::Type(level) => scan_level_bound(level, largest, nodes),
        Term::Inst(_, levels) => {
            for level in levels {
                scan_level_bound(level, largest, nodes);
            }
        }
        Term::Pi(_, left, right)
        | Term::Sigma(_, left, right)
        | Term::App(left, right)
        | Term::Pair(left, right)
        | Term::Ann(left, right) => {
            scan_term_level_bound(left, largest, nodes);
            scan_term_level_bound(right, largest, nodes);
        }
        Term::Lam(_, body) | Term::Fst(body) | Term::Snd(body) => {
            scan_term_level_bound(body, largest, nodes)
        }
        Term::Let(_, ty, value, body) => {
            scan_term_level_bound(ty, largest, nodes);
            scan_term_level_bound(value, largest, nodes);
            scan_term_level_bound(body, largest, nodes);
        }
        Term::Var(_) => {}
    }
}

// Max/successor expressions normalize to maxima of constants and
// `variable + offset` atoms.  Universal inequalities/equalities between such
// expressions are completely distinguished by the all-zero valuation and by
// making each variable, in turn, larger than every literal and syntactic
// successor offset in the declaration.
fn validation_level_envs(levels: &[String], terms: &[&Term]) -> Vec<HashMap<String, Nat>> {
    let mut largest = Nat::from(0);
    let mut nodes = 0;
    for term in terms {
        scan_term_level_bound(term, &mut largest, &mut nodes);
    }
    let mut high = largest;
    for _ in 0..=nodes {
        high = high.suc();
    }
    let zero_env: HashMap<String, Nat> = levels
        .iter()
        .map(|level| (level.clone(), Nat::from(0)))
        .collect();
    let mut environments = vec![zero_env.clone()];
    for level in levels {
        let mut environment = zero_env.clone();
        environment.insert(level.clone(), high.clone());
        environments.push(environment);
    }
    environments
}
fn subst_level(t: &Term, m: &HashMap<String, Nat>) -> Result<Term> {
    fn go(t: &Term, m: &HashMap<String, Nat>) -> Result<Term> {
        Ok(match t {
            Term::Type(l) => Term::Type(Level::Nat(eval_level(l, m)?)),
            Term::Var(x) => Term::Var(x.clone()),
            Term::Pi(x, a, b) => Term::Pi(x.clone(), Box::new(go(a, m)?), Box::new(go(b, m)?)),
            Term::Sigma(x, a, b) => {
                Term::Sigma(x.clone(), Box::new(go(a, m)?), Box::new(go(b, m)?))
            }
            Term::Lam(x, b) => Term::Lam(x.clone(), Box::new(go(b, m)?)),
            Term::App(f, a) => Term::App(Box::new(go(f, m)?), Box::new(go(a, m)?)),
            Term::Pair(a, b) => Term::Pair(Box::new(go(a, m)?), Box::new(go(b, m)?)),
            Term::Fst(a) => Term::Fst(Box::new(go(a, m)?)),
            Term::Snd(a) => Term::Snd(Box::new(go(a, m)?)),
            Term::Let(x, a, v, b) => Term::Let(
                x.clone(),
                Box::new(go(a, m)?),
                Box::new(go(v, m)?),
                Box::new(go(b, m)?),
            ),
            Term::Ann(a, b) => Term::Ann(Box::new(go(a, m)?), Box::new(go(b, m)?)),
            Term::Inst(x, ls) => Term::Inst(
                x.clone(),
                ls.iter()
                    .map(|l| Ok(Level::Nat(eval_level(l, m)?)))
                    .collect::<Result<_>>()?,
            ),
        })
    }
    go(t, m)
}

fn scope_poly_self(t: &Term, name: &str, levels: &[String]) -> Term {
    fn go(t: &Term, name: &str, levels: &[String], shadowed: bool) -> Term {
        match t {
            Term::Var(x) if x == name && !shadowed => declaration_ref(name, levels),
            Term::Pi(x, a, b) => Term::Pi(
                x.clone(),
                Box::new(go(a, name, levels, shadowed)),
                Box::new(go(b, name, levels, shadowed || x == name)),
            ),
            Term::Sigma(x, a, b) => Term::Sigma(
                x.clone(),
                Box::new(go(a, name, levels, shadowed)),
                Box::new(go(b, name, levels, shadowed || x == name)),
            ),
            Term::Lam(x, b) => Term::Lam(
                x.clone(),
                Box::new(go(b, name, levels, shadowed || x == name)),
            ),
            Term::App(f, a) => Term::App(
                Box::new(go(f, name, levels, shadowed)),
                Box::new(go(a, name, levels, shadowed)),
            ),
            Term::Pair(a, b) => Term::Pair(
                Box::new(go(a, name, levels, shadowed)),
                Box::new(go(b, name, levels, shadowed)),
            ),
            Term::Fst(a) => Term::Fst(Box::new(go(a, name, levels, shadowed))),
            Term::Snd(a) => Term::Snd(Box::new(go(a, name, levels, shadowed))),
            Term::Let(x, a, v, b) => Term::Let(
                x.clone(),
                Box::new(go(a, name, levels, shadowed)),
                Box::new(go(v, name, levels, shadowed)),
                Box::new(go(b, name, levels, shadowed || x == name)),
            ),
            Term::Ann(a, b) => Term::Ann(
                Box::new(go(a, name, levels, shadowed)),
                Box::new(go(b, name, levels, shadowed)),
            ),
            _ => t.clone(),
        }
    }
    go(t, name, levels, false)
}
fn free(t: &Term, x: &str) -> bool {
    match t {
        Term::Var(y) => x == y,
        Term::Type(_) | Term::Inst(_, _) => false,
        Term::Pi(y, a, b) | Term::Sigma(y, a, b) => free(a, x) || (y != x && free(b, x)),
        Term::Lam(y, b) => y != x && free(b, x),
        Term::App(a, b) | Term::Pair(a, b) | Term::Ann(a, b) => free(a, x) || free(b, x),
        Term::Fst(a) | Term::Snd(a) => free(a, x),
        Term::Let(y, a, v, b) => free(a, x) || free(v, x) || (y != x && free(b, x)),
    }
}
fn rename(t: &Term, old: &str, new: &str) -> Term {
    subst(t, old, &Term::Var(new.into()))
}
fn subst(t: &Term, x: &str, v: &Term) -> Term {
    fn bind(kind: u8, n: &str, a: Option<&Term>, b: &Term, x: &str, v: &Term) -> Term {
        let aa = a.map(|q| Box::new(subst(q, x, v)));
        if n == x {
            return match kind {
                0 => Term::Lam(n.into(), Box::new(b.clone())),
                1 => Term::Pi(n.into(), aa.unwrap(), Box::new(b.clone())),
                _ => Term::Sigma(n.into(), aa.unwrap(), Box::new(b.clone())),
            };
        }
        let (nn, bb) = if free(v, n) {
            let mut z = format!("{n}'");
            while free(b, &z) || free(v, &z) {
                z.push('\'')
            }
            (z.clone(), rename(b, n, &z))
        } else {
            (n.into(), b.clone())
        };
        let q = Box::new(subst(&bb, x, v));
        match kind {
            0 => Term::Lam(nn, q),
            1 => Term::Pi(nn, aa.unwrap(), q),
            _ => Term::Sigma(nn, aa.unwrap(), q),
        }
    }
    match t {
        Term::Var(y) => {
            if y == x {
                v.clone()
            } else {
                t.clone()
            }
        }
        Term::Type(_) | Term::Inst(_, _) => t.clone(),
        Term::Lam(n, b) => bind(0, n, None, b, x, v),
        Term::Pi(n, a, b) => bind(1, n, Some(a), b, x, v),
        Term::Sigma(n, a, b) => bind(2, n, Some(a), b, x, v),
        Term::App(a, b) => Term::App(Box::new(subst(a, x, v)), Box::new(subst(b, x, v))),
        Term::Pair(a, b) => Term::Pair(Box::new(subst(a, x, v)), Box::new(subst(b, x, v))),
        Term::Fst(a) => Term::Fst(Box::new(subst(a, x, v))),
        Term::Snd(a) => Term::Snd(Box::new(subst(a, x, v))),
        Term::Ann(a, b) => Term::Ann(Box::new(subst(a, x, v)), Box::new(subst(b, x, v))),
        Term::Let(n, a, w, b) => {
            let a = Box::new(subst(a, x, v));
            let w = Box::new(subst(w, x, v));
            if n == x {
                Term::Let(n.clone(), a, w, b.clone())
            } else if free(v, n) {
                let mut z = format!("{n}'");
                while free(b, &z) || free(v, &z) {
                    z.push('\'')
                }
                let bb = rename(b, n, &z);
                Term::Let(z, a, w, Box::new(subst(&bb, x, v)))
            } else {
                Term::Let(n.clone(), a, w, Box::new(subst(b, x, v)))
            }
        }
    }
}

fn lookup_local<'a>(c: &'a Ctx, x: &str) -> Option<&'a Local> {
    c.iter().rev().find(|q| q.name == x)
}
fn unapps(t: &Term) -> (&Term, Vec<&Term>) {
    let mut h = t;
    let mut a = Vec::new();
    while let Term::App(f, x) = h {
        a.push(x.as_ref());
        h = f
    }
    a.reverse();
    (h, a)
}
fn apps(mut f: Term, args: impl IntoIterator<Item = Term>) -> Term {
    for a in args {
        f = Term::App(Box::new(f), Box::new(a))
    }
    f
}
fn iota(t: &Term, e: &Env, c: &Ctx) -> Option<Term> {
    if !matches!(t, Term::App(_, _)) {
        return None;
    }
    let (h, args) = unapps(t);
    let rname = match h {
        Term::Var(x) | Term::Inst(x, _) => x,
        _ => return None,
    };
    let r = e.recs.get(rname)?;
    let need = r.outer_params
        + r.motives.len()
        + r.ctors.len()
        + if r.generalized_params {
            r.target_params
        } else {
            0
        }
        + r.indices
        + 1;
    if args.len() < need {
        return None;
    }
    // The scrutinee may expose its constructor only after beta/delta/iota
    // reduction (notably for higher-order recursive hypotheses).
    let reduced_target = whnf(args[need - 1].clone(), e, c).ok()?;
    let (ch, ca) = unapps(&reduced_target);
    let cname = match ch {
        Term::Var(x) | Term::Inst(x, _) => x,
        _ => return None,
    };
    let ci = e.ctors.get(cname)?;
    let bi = r.ctors.iter().position(|x| x == cname)?;
    let prefix: Vec<Term> = args[..r.outer_params + r.motives.len() + r.ctors.len()]
        .iter()
        .map(|x| (*x).clone())
        .collect();
    let constructor_params = *r.family_params.get(&ci.owner)?;
    if ca.len() < constructor_params + ci.fields.len() {
        return None;
    }
    let actual_params: Vec<Term> = ca[..constructor_params]
        .iter()
        .map(|x| (*x).clone())
        .collect();
    let actual_fields: Vec<Term> = ca[constructor_params..constructor_params + ci.fields.len()]
        .iter()
        .map(|x| (*x).clone())
        .collect();
    let mut bas = if r.generalized_params {
        actual_params.clone()
    } else {
        Vec::new()
    };
    bas.extend(actual_fields.clone());
    let mut ihs = Vec::new();
    for (j, (_, fty)) in ci.fields.iter().enumerate() {
        let mut instantiated = fty.clone();
        for ((name, _), value) in ci.fields[..j].iter().zip(&actual_fields[..j]) {
            instantiated = subst(&instantiated, name, value);
        }
        // Constructor field types mention parameters as local variables.
        // Instantiate them with the constructor's explicit parameter arguments.
        if let Some(g) = e.globals.get(cname) {
            let (ctor_params, _) = split_pis(&g.ty);
            for ((name, _), value) in ctor_params[..constructor_params].iter().zip(&actual_params) {
                instantiated = subst(&instantiated, name, value);
            }
        }
        if let Some((recursive_owner, tel, result_args)) =
            recursive_family_view(&instantiated, &r.motives)
        {
            let vars: Vec<Term> = tel
                .iter()
                .map(|(name, _)| Term::Var(name.clone()))
                .collect();
            let recursive_target = apps(actual_fields[j].clone(), vars);
            let recursive_params = *r.family_params.get(&recursive_owner)?;
            let mut result_args = result_args.into_iter();
            let recursive_parameter_values: Vec<Term> =
                result_args.by_ref().take(recursive_params).collect();
            let idx = result_args;
            let recursive_head = match h {
                Term::Inst(_, levels) => {
                    Term::Inst(format!("{recursive_owner}-rec"), levels.clone())
                }
                _ => Term::Var(format!("{recursive_owner}-rec")),
            };
            let call = apps(
                recursive_head,
                prefix
                    .clone()
                    .into_iter()
                    .chain(
                        r.generalized_params
                            .then_some(recursive_parameter_values)
                            .into_iter()
                            .flatten(),
                    )
                    .chain(idx)
                    .chain(std::iter::once(recursive_target)),
            );
            ihs.push(lams(&tel, call));
        }
    }
    bas.extend(ihs);
    let branch = args[r.outer_params + r.motives.len() + bi].clone();
    let mut out = apps(branch, bas);
    for x in &args[need..] {
        out = Term::App(Box::new(out), Box::new((*x).clone()))
    }
    Some(out)
}
fn whnf(t: Term, e: &Env, c: &Ctx) -> Result<Term> {
    if !c.is_empty() {
        return whnf_uncached(t, e, c);
    }
    if let Some(value) = e.whnf_cache.borrow().get(&t).cloned() {
        return Ok(value);
    }
    let key = t.clone();
    let value = whnf_uncached(t, e, c)?;
    let mut cache = e.whnf_cache.borrow_mut();
    // Bound memory on adversarial streams while retaining hot reductions.
    if cache.len() >= 65_536 {
        cache.clear();
    }
    cache.insert(key, value.clone());
    Ok(value)
}

fn whnf_uncached(mut t: Term, e: &Env, c: &Ctx) -> Result<Term> {
    for _ in 0..100000 {
        if let Some(x) = iota(&t, e, c) {
            t = x;
            continue;
        }
        match t {
            Term::Var(ref x) => {
                if let Some(q) = lookup_local(c, x).and_then(|q| q.val.as_ref()) {
                    t = q.clone();
                    continue;
                }
                if let Some(q) = e.globals.get(x).and_then(|q| q.val.as_ref()) {
                    t = q.clone();
                    continue;
                }
                return Ok(t);
            }
            Term::Inst(ref x, ref args) => {
                if let Some(g) = e.globals.get(x) {
                    if let Some(v) = &g.val {
                        if g.levels.len() == args.len() {
                            let mut m = HashMap::new();
                            for (n, a) in g.levels.iter().zip(args) {
                                m.insert(n.clone(), eval_level(a, &HashMap::new())?);
                            }
                            t = subst_level(v, &m)?;
                            continue;
                        }
                    }
                }
                return Ok(t);
            }
            Term::Ann(a, _) => {
                t = *a;
                continue;
            }
            Term::Let(x, _, v, b) => {
                t = subst(&b, &x, &v);
                continue;
            }
            Term::App(f, a) => {
                let fw = whnf(*f, e, c)?;
                if let Term::Lam(x, b) = fw {
                    t = subst(&b, &x, &a);
                    continue;
                }
                return Ok(Term::App(Box::new(fw), a));
            }
            Term::Fst(p) => {
                let pw = whnf(*p, e, c)?;
                if let Term::Pair(a, _) = pw {
                    t = *a;
                    continue;
                }
                return Ok(Term::Fst(Box::new(pw)));
            }
            Term::Snd(p) => {
                let pw = whnf(*p, e, c)?;
                if let Term::Pair(_, b) = pw {
                    t = *b;
                    continue;
                }
                return Ok(Term::Snd(Box::new(pw)));
            }
            _ => return Ok(t),
        }
    }
    Err("reduction limit exceeded".into())
}

fn universe(t: &Term, e: &Env, c: &mut Ctx, ls: &HashMap<String, Nat>) -> Result<Nat> {
    let ty = whnf(infer(t, e, c, ls)?, e, c)?;
    if let Term::Type(l) = ty {
        eval_level(&l, ls)
    } else {
        Err("expected a type".into())
    }
}

fn motive_universe(
    motive: &Term,
    expected: &Term,
    e: &Env,
    c: &mut Ctx,
    ls: &HashMap<String, Nat>,
) -> Result<Nat> {
    if let Term::Lam(name, body) = motive {
        let expected = whnf(expected.clone(), e, c)?;
        let Term::Pi(expected_name, domain, codomain) = expected else {
            return Err("recursor motive has too many lambda binders".into());
        };
        c.push(Local {
            name: name.clone(),
            ty: *domain,
            val: None,
        });
        let codomain = subst(&codomain, &expected_name, &Term::Var(name.clone()));
        let result = motive_universe(body, &codomain, e, c, ls);
        c.pop();
        result
    } else {
        let inferred = infer(motive, e, c, ls)?;
        type_family_universe(inferred, e, c, ls)
    }
}

fn type_family_universe(ty: Term, e: &Env, c: &mut Ctx, ls: &HashMap<String, Nat>) -> Result<Nat> {
    match whnf(ty, e, c)? {
        Term::Type(level) => eval_level(&level, ls),
        Term::Pi(name, domain, codomain) => {
            let local_name = fresh(c, "motive_arg");
            c.push(Local {
                name: local_name.clone(),
                ty: *domain,
                val: None,
            });
            let codomain = subst(&codomain, &name, &Term::Var(local_name));
            let result = type_family_universe(codomain, e, c, ls);
            c.pop();
            result
        }
        _ => Err("recursor motive does not return a type".into()),
    }
}

fn infer(t: &Term, e: &Env, c: &mut Ctx, ls: &HashMap<String, Nat>) -> Result<Term> {
    // A bare ordinary recursor leaves its generated motive universe implicit.
    // Infer that level from the motive's semantic result sort under its actual
    // telescope. Explicit `inst` remains authoritative, and polymorphic
    // declarations remain explicit.
    if matches!(t, Term::App(_, _)) {
        let (head, args) = unapps(t);
        if let Term::Var(name) = head {
            if let (Some(global), Some(rec)) = (e.globals.get(name), e.recs.get(name)) {
                if global.levels.len() == 1
                    && global.levels[0].starts_with("__elim_")
                    && args.len() > rec.outer_params
                {
                    let level_name = &global.levels[0];
                    let mut zero = HashMap::new();
                    zero.insert(level_name.clone(), Nat::from(0));
                    let mut recursor_type = subst_level(&global.ty, &zero)?;
                    for argument in &args[..rec.outer_params] {
                        let function_type = whnf(recursor_type, e, c)?;
                        let Term::Pi(binder, domain, codomain) = function_type else {
                            return Err("malformed generated recursor type".into());
                        };
                        check(argument, &domain, e, c, ls)?;
                        recursor_type = subst(&codomain, &binder, argument);
                    }
                    let recursor_type = whnf(recursor_type, e, c)?;
                    let Term::Pi(_, motive_type, _) = recursor_type else {
                        return Err("malformed generated recursor motive".into());
                    };
                    let inferred_level =
                        motive_universe(args[rec.outer_params], &motive_type, e, c, ls)?;
                    let elaborated = apps(
                        Term::Inst(name.clone(), vec![Level::Nat(inferred_level)]),
                        args.iter().map(|arg| (*arg).clone()),
                    );
                    return infer(&elaborated, e, c, ls);
                }
            }
        }
    }
    match t {
        Term::Var(x) => lookup_local(c, x)
            .map(|q| q.ty.clone())
            .or_else(|| {
                e.globals.get(x).and_then(|g| {
                    if g.levels.is_empty() {
                        Some(g.ty.clone())
                    } else if g.levels.len() == 1 && g.levels[0].starts_with("__elim_") {
                        let mut levels = HashMap::new();
                        levels.insert(g.levels[0].clone(), Nat::from(0));
                        subst_level(&g.ty, &levels).ok()
                    } else {
                        None
                    }
                })
            })
            .ok_or_else(|| format!("unknown identifier {x}")),
        Term::Inst(x, args) => {
            let g = e
                .globals
                .get(x)
                .ok_or_else(|| format!("unknown identifier {x}"))?;
            if g.levels.len() != args.len() {
                return Err(format!("wrong number of universe arguments for {x}"));
            }
            let mut m = HashMap::new();
            for (n, a) in g.levels.iter().zip(args) {
                m.insert(n.clone(), eval_level(a, ls)?);
            }
            if let Some(rec) = e.recs.get(x) {
                let sort = eval_level(&rec.sort, &m)?;
                let elim = m.get(g.levels.last().unwrap()).unwrap();
                if rec.ctors.len() > 1 && sort == Nat::from(0) && !elim.le(&Nat::from(0)) {
                    return Err(
                        "prohibited large elimination from a multi-constructor Type 0 inductive"
                            .into(),
                    );
                }
            }
            subst_level(&g.ty, &m)
        }
        Term::Type(l) => Ok(Term::Type(Level::Nat(eval_level(l, ls)?.suc()))),
        Term::Pi(x, a, b) | Term::Sigma(x, a, b) => {
            let i = universe(a, e, c, ls)?;
            c.push(Local {
                name: x.clone(),
                ty: *a.clone(),
                val: None,
            });
            let j = universe(b, e, c, ls);
            c.pop();
            Ok(Term::Type(Level::Nat(i.max(j?))))
        }
        Term::Ann(x, a) => {
            universe(a, e, c, ls)?;
            check(x, a, e, c, ls)?;
            Ok(*a.clone())
        }
        Term::App(f, a) => {
            let ft = whnf(infer(f, e, c, ls)?, e, c)?;
            if let Term::Pi(x, d, b) = ft {
                check(a, &d, e, c, ls)?;
                Ok(subst(&b, &x, a))
            } else {
                Err("application of non-function".into())
            }
        }
        Term::Fst(p) => {
            let pt = whnf(infer(p, e, c, ls)?, e, c)?;
            if let Term::Sigma(_, a, _) = pt {
                Ok(*a)
            } else {
                Err("fst of non-pair".into())
            }
        }
        Term::Snd(p) => {
            let pt = whnf(infer(p, e, c, ls)?, e, c)?;
            if let Term::Sigma(x, _, b) = pt {
                Ok(subst(&b, &x, &Term::Fst(p.clone())))
            } else {
                Err("snd of non-pair".into())
            }
        }
        Term::Let(x, a, v, b) => {
            universe(a, e, c, ls)?;
            check(v, a, e, c, ls)?;
            c.push(Local {
                name: x.clone(),
                ty: *a.clone(),
                val: Some(*v.clone()),
            });
            let r = infer(b, e, c, ls);
            c.pop();
            r.map(|result| subst(&result, x, v))
        }
        Term::Lam(_, _) => Err("cannot infer lambda; add an annotation".into()),
        Term::Pair(_, _) => Err("cannot infer pair; add an annotation".into()),
    }
}
fn check(t: &Term, expected: &Term, e: &Env, c: &mut Ctx, ls: &HashMap<String, Nat>) -> Result<()> {
    match t {
        Term::Lam(x, b) => {
            let ex = whnf(expected.clone(), e, c)?;
            let Term::Pi(y, a, r) = ex else {
                return Err("lambda checked against a non-function type".into());
            };
            c.push(Local {
                name: x.clone(),
                ty: *a,
                val: None,
            });
            let rr = subst(&r, &y, &Term::Var(x.clone()));
            let z = check(b, &rr, e, c, ls);
            c.pop();
            z
        }
        Term::Pair(a, b) => {
            let ex = whnf(expected.clone(), e, c)?;
            let Term::Sigma(x, d, r) = ex else {
                return Err("pair checked against a non-Sigma type".into());
            };
            check(a, &d, e, c, ls)?;
            check(b, &subst(&r, &x, a), e, c, ls)
        }
        _ => {
            let got = infer(t, e, c, ls)?;
            if subtype(&got, expected, e, c, ls)? {
                Ok(())
            } else {
                Err(format!(
                    "type mismatch: inferred {:?}, expected {:?}",
                    got, expected
                ))
            }
        }
    }
}
fn subtype(a: &Term, b: &Term, e: &Env, c: &mut Ctx, ls: &HashMap<String, Nat>) -> Result<bool> {
    if a == b {
        return Ok(true);
    }
    let aw = whnf(a.clone(), e, c)?;
    let bw = whnf(b.clone(), e, c)?;
    if let (Term::Type(x), Term::Type(y)) = (&aw, &bw) {
        return Ok(eval_level(x, ls)?.le(&eval_level(y, ls)?));
    }
    conv(&aw, &bw, None, e, c, ls)
}
fn conv(
    a: &Term,
    b: &Term,
    ty: Option<&Term>,
    e: &Env,
    c: &mut Ctx,
    ls: &HashMap<String, Nat>,
) -> Result<bool> {
    // Keep identical definitions folded; most kernel conversions end here.
    if a == b {
        return Ok(true);
    }
    let aw = whnf(a.clone(), e, c)?;
    let bw = whnf(b.clone(), e, c)?;
    if aw == bw {
        return Ok(true);
    }
    if ty.is_none()
        && (matches!(
            (&aw, &bw),
            (Term::Lam(_, _), _)
                | (_, Term::Lam(_, _))
                | (Term::Pair(_, _), _)
                | (_, Term::Pair(_, _))
        ))
    {
        if let Ok(t) = infer(&aw, e, c, ls).or_else(|_| infer(&bw, e, c, ls)) {
            return conv(&aw, &bw, Some(&t), e, c, ls);
        }
    }
    if let Some(t) = ty {
        match whnf(t.clone(), e, c)? {
            Term::Pi(x, d, r) => {
                let z = fresh(c, "eta");
                c.push(Local {
                    name: z.clone(),
                    ty: *d,
                    val: None,
                });
                let rt = subst(&r, &x, &Term::Var(z.clone()));
                let aa = Term::App(Box::new(aw.clone()), Box::new(Term::Var(z.clone())));
                let bb = Term::App(Box::new(bw.clone()), Box::new(Term::Var(z)));
                let q = conv(&aa, &bb, Some(&rt), e, c, ls);
                c.pop();
                return q;
            }
            Term::Sigma(x, d, r) => {
                let fa = Term::Fst(Box::new(aw.clone()));
                let fb = Term::Fst(Box::new(bw.clone()));
                if !conv(&fa, &fb, Some(&d), e, c, ls)? {
                    return Ok(false);
                }
                let rt = subst(&r, &x, &fa);
                return conv(
                    &Term::Snd(Box::new(aw)),
                    &Term::Snd(Box::new(bw)),
                    Some(&rt),
                    e,
                    c,
                    ls,
                );
            }
            _ => {}
        }
    }
    match (&aw, &bw) {
        (Term::Type(x), Term::Type(y)) => Ok(eval_level(x, ls)? == eval_level(y, ls)?),
        (Term::Var(x), Term::Var(y)) => Ok(x == y),
        (Term::Pi(x, a, r), Term::Pi(y, b, s)) | (Term::Sigma(x, a, r), Term::Sigma(y, b, s)) => {
            if !conv(a, b, None, e, c, ls)? {
                return Ok(false);
            }
            let z = fresh(c, "cv");
            let rr = subst(r, x, &Term::Var(z.clone()));
            let ss = subst(s, y, &Term::Var(z.clone()));
            c.push(Local {
                name: z,
                ty: *a.clone(),
                val: None,
            });
            let q = conv(&rr, &ss, None, e, c, ls);
            c.pop();
            q
        }
        (Term::Lam(x, r), Term::Lam(y, s)) => {
            let z = fresh(c, "cv");
            conv(
                &subst(r, x, &Term::Var(z.clone())),
                &subst(s, y, &Term::Var(z)),
                None,
                e,
                c,
                ls,
            )
        }
        (Term::App(f, a), Term::App(g, b)) => {
            Ok(conv(f, g, None, e, c, ls)? && conv(a, b, None, e, c, ls)?)
        }
        (Term::Pair(a, b), Term::Pair(x, y)) => {
            Ok(conv(a, x, None, e, c, ls)? && conv(b, y, None, e, c, ls)?)
        }
        (Term::Fst(a), Term::Fst(b)) | (Term::Snd(a), Term::Snd(b)) => conv(a, b, None, e, c, ls),
        _ => Ok(false),
    }
}
fn fresh(c: &Ctx, p: &str) -> String {
    let mut x: String = p.into();
    while c.iter().any(|q| q.name == x) {
        x.push('\'')
    }
    x
}

fn process(src: &str, e: &mut Env) -> Result<()> {
    for s in sexps(src)? {
        // Declarations extend the reduction environment.  Command-local
        // memoization must never retain a neutral that a later declaration
        // turns into a delta-reducible global.
        e.whnf_cache.get_mut().clear();
        command(&s, e)?
    }
    Ok(())
}
fn command(s: &Sexp, e: &mut Env) -> Result<()> {
    let v = if let Sexp::List(v) = s {
        v
    } else {
        return Err("command must be a list".into());
    };
    if v.is_empty() {
        return Err("empty command".into());
    }
    match atom(&v[0])? {
        "check" if v.len() == 3 => {
            let t = term(&v[1])?;
            let a = term(&v[2])?;
            let mut c = Vec::new();
            let ls = HashMap::new();
            universe(&a, e, &mut c, &ls)?;
            check(&t, &a, e, &mut c, &ls)
        }
        "def" if v.len() == 4 => definition(
            identifier(&v[1])?,
            Vec::new(),
            term(&v[2])?,
            term(&v[3])?,
            e,
        ),
        "def-poly" if v.len() == 5 => {
            let xs = level_binders(&v[2])?;
            definition(identifier(&v[1])?, xs, term(&v[3])?, term(&v[4])?, e)
        }
        "inductive" => inductive(v, e, Vec::new()),
        "inductive-poly" if v.len() >= 3 => {
            let levels = level_binders(&v[2])?;
            inductive(v, e, levels)
        }
        "mutual" => mutual(v, e),
        x => Err(format!("unsupported or malformed command {x}")),
    }
}
fn level_binders(s: &Sexp) -> Result<Vec<String>> {
    let outer = if let Sexp::List(x) = s {
        x
    } else {
        return Err("expected universe binder list".into());
    };
    let xs = if outer.len() == 1 {
        if let Sexp::List(x) = &outer[0] {
            x
        } else {
            outer
        }
    } else {
        outer
    };
    let mut seen = HashSet::new();
    xs.iter()
        .map(|x| {
            let x = atom(x)?.to_string();
            if !valid_id(&x) || !seen.insert(x.clone()) {
                Err("invalid universe binder".into())
            } else {
                Ok(x)
            }
        })
        .collect()
}
fn definition(name: &str, levels: Vec<String>, ty: Term, val: Term, e: &mut Env) -> Result<()> {
    if !valid_id(name) {
        return Err(format!("invalid identifier '{name}'"));
    }
    if e.globals.contains_key(name) {
        return Err(format!("duplicate declaration {name}"));
    }
    for level_environment in validation_level_envs(&levels, &[&ty, &val]) {
        let mut context = Vec::new();
        universe(&ty, e, &mut context, &level_environment)?;
        check(&val, &ty, e, &mut context, &level_environment)?;
    }
    e.globals.insert(
        name.into(),
        Global {
            ty,
            val: Some(val),
            levels,
        },
    );
    Ok(())
}

fn telescope(s: &Sexp) -> Result<Vec<(String, Term)>> {
    let v = if let Sexp::List(v) = s {
        v
    } else {
        return Err("expected telescope".into());
    };
    v.iter().map(binder).collect()
}
fn tagged<'a>(v: &'a [Sexp], tag: &str) -> Result<&'a [Sexp]> {
    v.iter()
        .find_map(|x| {
            if let Sexp::List(z) = x {
                if z.first().and_then(|a| atom(a).ok()) == Some(tag) {
                    Some(&z[1..])
                } else {
                    None
                }
            } else {
                None
            }
        })
        .ok_or_else(|| format!("missing {tag} section"))
}
fn pis(xs: &[(String, Term)], body: Term) -> Term {
    xs.iter().rev().fold(body, |b, (x, a)| {
        Term::Pi(x.clone(), Box::new(a.clone()), Box::new(b))
    })
}
fn split_pis(t: &Term) -> (Vec<(String, Term)>, Term) {
    let mut xs = Vec::new();
    let mut q = t;
    while let Term::Pi(x, a, b) = q {
        xs.push((x.clone(), *a.clone()));
        q = b
    }
    (xs, q.clone())
}
fn declaration_ref(name: &str, levels: &[String]) -> Term {
    if levels.is_empty() {
        Term::Var(name.into())
    } else {
        Term::Inst(
            name.into(),
            levels.iter().map(|x| Level::Var(x.clone())).collect(),
        )
    }
}
fn declaration_apps(name: &str, levels: &[String], xs: &[(String, Term)]) -> Term {
    apps(
        declaration_ref(name, levels),
        xs.iter().map(|(x, _)| Term::Var(x.clone())),
    )
}
fn head_name(t: &Term) -> Option<(&str, Vec<&Term>)> {
    let (h, a) = unapps(t);
    match h {
        Term::Var(x) | Term::Inst(x, _) => Some((x, a)),
        _ => None,
    }
}
fn occurs(t: &Term, n: &str) -> bool {
    match t {
        Term::Var(x) => x == n,
        Term::Type(_) => false,
        Term::Inst(name, _) => name == n,
        Term::Pi(_, a, b)
        | Term::Sigma(_, a, b)
        | Term::App(a, b)
        | Term::Pair(a, b)
        | Term::Ann(a, b) => occurs(a, n) || occurs(b, n),
        Term::Lam(_, b) | Term::Fst(b) | Term::Snd(b) => occurs(b, n),
        Term::Let(_, a, v, b) => occurs(a, n) || occurs(v, n) || occurs(b, n),
    }
}
fn positive_arg(t: &Term, n: &str) -> bool {
    if !occurs(t, n) {
        return true;
    }
    if head_name(t).map(|x| x.0) == Some(n) {
        return true;
    }
    if let Term::Pi(_, a, b) = t {
        !occurs(a, n) && positive_arg(b, n)
    } else {
        false
    }
}
fn recursive_view(t: &Term, owner: &str) -> Option<(Vec<(String, Term)>, Vec<Term>)> {
    let (tel, result) = split_pis(t);
    let (head, args) = head_name(&result)?;
    (head == owner).then(|| (tel, args.into_iter().cloned().collect()))
}
fn recursive_family_view(
    t: &Term,
    families: &[String],
) -> Option<(String, Vec<(String, Term)>, Vec<Term>)> {
    let (tel, result) = split_pis(t);
    let (head, args) = head_name(&result)?;
    families
        .contains(&head.to_string())
        .then(|| (head.to_string(), tel, args.into_iter().cloned().collect()))
}
fn lams(xs: &[(String, Term)], body: Term) -> Term {
    xs.iter()
        .rev()
        .fold(body, |b, (x, _)| Term::Lam(x.clone(), Box::new(b)))
}
fn motive_app(m: &str, idx: impl IntoIterator<Item = Term>, target: Term) -> Term {
    apps(
        Term::Var(m.into()),
        idx.into_iter().chain(std::iter::once(target)),
    )
}

fn inductive(v: &[Sexp], e: &mut Env, levels: Vec<String>) -> Result<()> {
    if v.len() < 2 {
        return Err("malformed inductive".into());
    }
    let name = identifier(&v[1])?.to_string();
    if e.globals.contains_key(&name) {
        return Err(format!("duplicate declaration {name}"));
    }
    let ps = tagged(v, "params")?;
    if ps.len() != 1 {
        return Err("malformed params".into());
    }
    let params = telescope(&ps[0])?;
    let is = tagged(v, "indices")?;
    if is.len() != 1 {
        return Err("malformed indices".into());
    }
    let indices = telescope(&is[0])?;
    let ss = tagged(v, "sort")?;
    if ss.len() != 1 {
        return Err("malformed sort".into());
    }
    let sort = term(&ss[0])?;
    let sort_level = if let Term::Type(l) = &sort {
        l.clone()
    } else {
        return Err("inductive sort must be Type".into());
    };
    let mut all = params.clone();
    all.extend(indices.clone());
    let ity = pis(&all, sort.clone());
    for level_environment in validation_level_envs(&levels, &[&ity]) {
        universe(&ity, e, &mut Vec::new(), &level_environment)?;
    }
    e.globals.insert(
        name.clone(),
        Global {
            ty: ity,
            val: None,
            levels: levels.clone(),
        },
    );
    let cs = tagged(v, "constructors")?;
    if cs.len() != 1 {
        return Err("malformed constructors".into());
    }
    let rows = if let Sexp::List(z) = &cs[0] {
        z
    } else {
        return Err("malformed constructors".into());
    };
    let mut cnames = Vec::new();
    let mut raw_info = Vec::new();
    for row in rows {
        let z = if let Sexp::List(z) = row {
            z
        } else {
            return Err("malformed constructor".into());
        };
        if z.len() != 3 || atom(&z[1])? != ":" {
            return Err("malformed constructor".into());
        }
        let cn = identifier(&z[0])?.to_string();
        if e.globals.contains_key(&cn) {
            return Err(format!("duplicate declaration {cn}"));
        }
        let raw = scope_poly_self(&term(&z[2])?, &name, &levels);
        let (fields, res) = split_pis(&raw);
        for (_, a) in &fields {
            if !positive_arg(a, &name) {
                return Err(format!(
                    "non-strictly-positive occurrence of {name} in {cn}"
                ));
            }
        }
        let (h, args) =
            head_name(&res).ok_or_else(|| format!("constructor {cn} does not return {name}"))?;
        if h != name || args.len() != params.len() + indices.len() {
            return Err(format!("constructor {cn} has invalid result"));
        }
        for ((param, _), argument) in params.iter().zip(&args) {
            if **argument != Term::Var(param.clone()) {
                return Err(format!(
                    "constructor {cn} does not preserve parameter {param}"
                ));
            }
        }
        let cty = pis(&params, raw.clone());
        for level_environment in validation_level_envs(&levels, &[&cty]) {
            universe(&cty, e, &mut Vec::new(), &level_environment)?;
        }
        e.globals.insert(
            cn.clone(),
            Global {
                ty: cty,
                val: None,
                levels: levels.clone(),
            },
        );
        e.ctors.insert(
            cn.clone(),
            CtorInfo {
                owner: name.clone(),
                fields: fields.clone(),
            },
        );
        cnames.push(cn);
        raw_info.push((fields, res));
    }
    // Generate the ordinary recursor at the inductive's sort universe.
    let motive = "motive".to_string();
    let elim_level = format!("__elim_{name}");
    let t_at = declaration_apps(&name, &levels, &all);
    let motive_ty = pis(
        &indices,
        Term::Pi(
            "target".into(),
            Box::new(t_at.clone()),
            Box::new(Term::Type(Level::Var(elim_level.clone()))),
        ),
    );
    let mut branches = Vec::new();
    for ((fields, res), cn) in raw_info.iter().zip(&cnames) {
        let (_, rargs) = head_name(res).unwrap();
        let ridx: Vec<Term> = rargs
            .iter()
            .skip(params.len())
            .map(|x| (*x).clone())
            .collect();
        let ctor = apps(
            declaration_ref(cn, &levels),
            params
                .iter()
                .chain(fields.iter())
                .map(|(x, _)| Term::Var(x.clone())),
        );
        let mut tel = fields.clone();
        for (j, (x, a)) in fields.iter().enumerate() {
            if let Some((recursive_tel, aa)) = recursive_view(a, &name) {
                let target = apps(
                    Term::Var(x.clone()),
                    recursive_tel
                        .iter()
                        .map(|(name, _)| Term::Var(name.clone())),
                );
                let ih = pis(
                    &recursive_tel,
                    motive_app(&motive, aa.into_iter().skip(params.len()), target),
                );
                tel.push((format!("ih_{j}"), ih));
            }
        }
        branches.push((
            format!("branch_{}", branches.len()),
            pis(&tel, motive_app(&motive, ridx, ctor)),
        ));
    }
    let target = ("target".into(), t_at);
    let result = motive_app(
        &motive,
        indices.iter().map(|(x, _)| Term::Var(x.clone())),
        Term::Var("target".into()),
    );
    let mut tail = indices.clone();
    tail.push(target);
    let mut rec_parts = Vec::new();
    rec_parts.extend(params.clone());
    rec_parts.push((motive, motive_ty));
    rec_parts.extend(branches);
    rec_parts.extend(tail);
    let rty = pis(&rec_parts, result);
    let rn = format!("{name}-rec");
    let mut rec_levels = levels.clone();
    rec_levels.push(elim_level);
    e.globals.insert(
        rn.clone(),
        Global {
            ty: rty,
            val: None,
            levels: rec_levels,
        },
    );
    e.recs.insert(
        rn,
        RecInfo {
            outer_params: params.len(),
            target_params: params.len(),
            generalized_params: false,
            indices: indices.len(),
            ctors: cnames,
            motives: vec![name.clone()],
            family_params: [(name.clone(), params.len())].into_iter().collect(),
            sort: sort_level,
        },
    );
    Ok(())
}

struct MutualDecl {
    name: String,
    params: Vec<(String, Term)>,
    indices: Vec<(String, Term)>,
    sort: Level,
    constructors: Vec<(String, Vec<(String, Term)>, Term)>,
}

fn mutual(v: &[Sexp], e: &mut Env) -> Result<()> {
    if v.len() < 3 {
        return Err("a mutual block needs at least two inductives".into());
    }
    let mut declarations = Vec::new();
    // Parse all headers before adding anything, then make every family visible
    // simultaneously while constructor types are checked.
    for item in &v[1..] {
        let parts = if let Sexp::List(parts) = item {
            parts
        } else {
            return Err("malformed mutual member".into());
        };
        if parts.first().and_then(|x| atom(x).ok()) != Some("inductive") {
            return Err("mutual blocks may contain only inductive declarations".into());
        }
        let name = identifier(parts.get(1).ok_or("missing mutual family name")?)?.to_string();
        if e.globals.contains_key(&name) || declarations.iter().any(|d: &MutualDecl| d.name == name)
        {
            return Err(format!("duplicate declaration {name}"));
        }
        let params_section = tagged(parts, "params")?;
        let params = telescope(params_section.first().ok_or("malformed params")?)?;
        let indices_section = tagged(parts, "indices")?;
        let indices = telescope(indices_section.first().ok_or("malformed indices")?)?;
        let sort_section = tagged(parts, "sort")?;
        let sort_term = term(sort_section.first().ok_or("malformed sort")?)?;
        let sort = if let Term::Type(level) = sort_term {
            level
        } else {
            return Err("mutual inductive sort must be Type".into());
        };
        let constructors_section = tagged(parts, "constructors")?;
        let rows = if let Some(Sexp::List(rows)) = constructors_section.first() {
            rows
        } else {
            return Err("malformed constructors".into());
        };
        let mut constructors = Vec::new();
        for row in rows {
            let fields = if let Sexp::List(fields) = row {
                fields
            } else {
                return Err("malformed constructor".into());
            };
            if fields.len() != 3 || atom(&fields[1])? != ":" {
                return Err("malformed constructor".into());
            }
            let constructor = identifier(&fields[0])?.to_string();
            let raw = term(&fields[2])?;
            let (arguments, result) = split_pis(&raw);
            constructors.push((constructor, arguments, result));
        }
        declarations.push(MutualDecl {
            name,
            params,
            indices,
            sort,
            constructors,
        });
    }
    let shared_params = declarations[0].params.clone();
    let shared_mode = declarations.iter().all(|decl| decl.params == shared_params);
    let empty_levels = HashMap::new();
    for decl in &declarations {
        let mut telescope = decl.params.clone();
        telescope.extend(decl.indices.clone());
        let ty = pis(&telescope, Term::Type(decl.sort.clone()));
        e.globals.insert(
            decl.name.clone(),
            Global {
                ty,
                val: None,
                levels: Vec::new(),
            },
        );
    }
    for decl in &declarations {
        let ty = e.globals[&decl.name].ty.clone();
        universe(&ty, e, &mut Vec::new(), &empty_levels)?;
    }
    let families: Vec<String> = declarations.iter().map(|d| d.name.clone()).collect();
    let mut all_constructors = Vec::new();
    for decl in &declarations {
        for (constructor, fields, result) in &decl.constructors {
            if e.globals.contains_key(constructor) {
                return Err(format!("duplicate declaration {constructor}"));
            }
            for (_, field_type) in fields {
                for family in &families {
                    if !positive_arg(field_type, family) {
                        return Err(format!(
                            "non-strictly-positive occurrence of {family} in {constructor}"
                        ));
                    }
                }
            }
            let (head, result_args) = head_name(result)
                .ok_or_else(|| format!("constructor {constructor} has invalid result"))?;
            if head != decl.name || result_args.len() != decl.params.len() + decl.indices.len() {
                return Err(format!("constructor {constructor} has invalid result"));
            }
            for ((parameter, _), argument) in decl.params.iter().zip(&result_args) {
                if **argument != Term::Var(parameter.clone()) {
                    return Err(format!(
                        "constructor {constructor} does not preserve parameter {parameter}"
                    ));
                }
            }
            let raw = pis(&decl.params, pis(fields, result.clone()));
            universe(&raw, e, &mut Vec::new(), &empty_levels)?;
            e.globals.insert(
                constructor.clone(),
                Global {
                    ty: raw,
                    val: None,
                    levels: Vec::new(),
                },
            );
            e.ctors.insert(
                constructor.clone(),
                CtorInfo {
                    owner: decl.name.clone(),
                    fields: fields.clone(),
                },
            );
            all_constructors.push(constructor.clone());
        }
    }
    let family_params: HashMap<String, usize> = families
        .iter()
        .zip(&declarations)
        .map(|(name, decl)| (name.clone(), decl.params.len()))
        .collect();
    for target_decl in &declarations {
        let elim_level = format!("__elim_{}", target_decl.name);
        let motive_names: HashMap<String, String> = families
            .iter()
            .map(|name| (name.clone(), format!("motive_{name}")))
            .collect();
        let motives: Vec<(String, Term)> = declarations
            .iter()
            .map(|decl| {
                let mut family_arguments = decl.params.clone();
                family_arguments.extend(decl.indices.clone());
                let applied = declaration_apps(&decl.name, &[], &family_arguments);
                (
                    motive_names[&decl.name].clone(),
                    pis(
                        &if shared_mode {
                            decl.indices.clone()
                        } else {
                            family_arguments.clone()
                        },
                        Term::Pi(
                            "target".into(),
                            Box::new(applied),
                            Box::new(Term::Type(Level::Var(elim_level.clone()))),
                        ),
                    ),
                )
            })
            .collect();
        let mut branches = Vec::new();
        for owner_decl in &declarations {
            for (constructor, fields, result) in &owner_decl.constructors {
                let (_, result_args) = head_name(result).unwrap();
                let constructor_term = apps(
                    Term::Var(constructor.clone()),
                    owner_decl
                        .params
                        .iter()
                        .chain(fields.iter())
                        .map(|(name, _)| Term::Var(name.clone())),
                );
                let mut telescope = if shared_mode {
                    fields.clone()
                } else {
                    let mut telescope = owner_decl.params.clone();
                    telescope.extend(fields.clone());
                    telescope
                };
                for (position, (field, field_type)) in fields.iter().enumerate() {
                    if let Some((recursive_owner, recursive_tel, args)) =
                        recursive_family_view(field_type, &families)
                    {
                        let recursive_target = apps(
                            Term::Var(field.clone()),
                            recursive_tel
                                .iter()
                                .map(|(name, _)| Term::Var(name.clone())),
                        );
                        telescope.push((
                            format!("ih_{position}"),
                            pis(
                                &recursive_tel,
                                motive_app(
                                    &motive_names[&recursive_owner],
                                    args.into_iter().skip(if shared_mode {
                                        family_params[&recursive_owner]
                                    } else {
                                        0
                                    }),
                                    recursive_target,
                                ),
                            ),
                        ));
                    }
                }
                branches.push((
                    format!("branch_{}", branches.len()),
                    pis(
                        &telescope,
                        motive_app(
                            &motive_names[&owner_decl.name],
                            result_args
                                .into_iter()
                                .skip(if shared_mode {
                                    owner_decl.params.len()
                                } else {
                                    0
                                })
                                .cloned(),
                            constructor_term,
                        ),
                    ),
                ));
            }
        }
        let mut target_arguments = target_decl.params.clone();
        target_arguments.extend(target_decl.indices.clone());
        let target_type = declaration_apps(&target_decl.name, &[], &target_arguments);
        let mut ending = if shared_mode {
            target_decl.indices.clone()
        } else {
            target_arguments.clone()
        };
        ending.push(("target".into(), target_type));
        let result_arguments = if shared_mode {
            target_decl.indices.clone()
        } else {
            target_arguments.clone()
        };
        let result = motive_app(
            &motive_names[&target_decl.name],
            result_arguments
                .iter()
                .map(|(name, _)| Term::Var(name.clone())),
            Term::Var("target".into()),
        );
        let mut recursor_telescope = if shared_mode {
            shared_params.clone()
        } else {
            Vec::new()
        };
        recursor_telescope.extend(motives.clone());
        recursor_telescope.extend(branches);
        recursor_telescope.extend(ending);
        let recursor_name = format!("{}-rec", target_decl.name);
        e.globals.insert(
            recursor_name.clone(),
            Global {
                ty: pis(&recursor_telescope, result),
                val: None,
                levels: vec![elim_level],
            },
        );
        e.recs.insert(
            recursor_name,
            RecInfo {
                outer_params: if shared_mode { shared_params.len() } else { 0 },
                target_params: target_decl.params.len(),
                generalized_params: !shared_mode,
                indices: target_decl.indices.len(),
                ctors: all_constructors.clone(),
                motives: families.clone(),
                family_params: family_params.clone(),
                sort: target_decl.sort.clone(),
            },
        );
    }
    Ok(())
}

fn main() {
    let args: Vec<_> = env::args_os().skip(1).collect();
    if args.is_empty() {
        eprintln!("usage: type-checker <file> [file ...]");
        process::exit(1)
    }
    let mut e = Env::default();
    for p in args {
        let src = match fs::read_to_string(&p) {
            Ok(x) => x,
            Err(x) => {
                eprintln!("{}: {x}", p.to_string_lossy());
                process::exit(1)
            }
        };
        if let Err(x) = process(&src, &mut e) {
            eprintln!("{}: {x}", p.to_string_lossy());
            process::exit(1)
        }
    }
}
