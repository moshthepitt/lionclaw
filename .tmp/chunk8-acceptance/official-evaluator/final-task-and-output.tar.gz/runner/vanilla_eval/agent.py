"""Harbor adapter that invokes the unmodified `lionclaw run [runtime]` path.

This module is external evaluation glue. It supplies Harbor's original task
instruction to the vanilla LionClaw terminal, observes terminal mission state,
collects the resulting commit, and returns that artifact to Harbor. It does not
select prompts, roles, oracles, retry rules, finish rules, or mission types.
"""

from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import os
import pty
import re
import select
import signal
import struct
import subprocess
import termios
import threading
import time
from pathlib import Path
from typing import Any

from harbor.agents.base import BaseAgent
from harbor.environments.base import BaseEnvironment
from harbor.models.agent.context import AgentContext

ANSI_ESCAPE = re.compile(
    rb"(?:\x1b\][^\x07]*(?:\x07|\x1b\\)|\x1b[P^_].*?\x1b\\|\x1b[@-_][0-?]*[ -/]*[@-~])",
    re.DOTALL,
)


class VanillaLionClawAgent(BaseAgent):
    def __init__(
        self,
        *args: Any,
        lionclaw_bin: str,
        lionclaw_home: str,
        official_instruction_sha256: str,
        runtime: str = "codex",
        bootstrap_wait_secs: int = 900,
        startup_wait_secs: int = 10,
        poll_secs: int = 15,
        max_secs: int = 72000,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.lionclaw_bin = Path(lionclaw_bin).resolve()
        self.lionclaw_home = Path(lionclaw_home).resolve()
        self.official_instruction_sha256 = official_instruction_sha256
        self.runtime = runtime
        self.startup_wait_secs = int(startup_wait_secs)
        self.bootstrap_wait_secs = int(bootstrap_wait_secs)
        self.poll_secs = int(poll_secs)
        self.max_secs = int(max_secs)

    @staticmethod
    def name() -> str:
        return "lionclaw-vanilla"

    def version(self) -> str:
        return "chunk8-official-v3"

    async def setup(self, environment: BaseEnvironment) -> None:
        del environment

    @staticmethod
    def _git(repo: Path, *args: str) -> str:
        completed = subprocess.run(
            ["git", "-C", str(repo), *args],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"git {' '.join(args)} failed:\n{completed.stdout}\n{completed.stderr}"
            )
        return completed.stdout.strip()

    def _initialize_repo(self, repo: Path) -> str:
        self._git(repo, "init", "--initial-branch=official-base")
        self._git(repo, "config", "user.name", "LionClaw Official Evaluation")
        self._git(repo, "config", "user.email", "evaluation@lionclaw.invalid")
        self._git(repo, "config", "commit.gpgsign", "false")
        self._git(repo, "add", "-A")
        self._git(repo, "commit", "-m", "Initialize official task workspace")
        return self._git(repo, "rev-parse", "HEAD")

    @staticmethod
    def _write_all(fd: int, data: bytes) -> None:
        view = memoryview(data)
        while view:
            written = os.write(fd, view)
            view = view[written:]

    def _report(self, repo: Path, environment: dict[str, str]) -> dict[str, Any] | None:
        completed = subprocess.run(
            [
                str(self.lionclaw_bin),
                "mission",
                "report",
                "--repo",
                str(repo),
                "--json",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=environment,
            check=False,
        )
        if completed.returncode != 0:
            return None
        try:
            return json.loads(completed.stdout)
        except json.JSONDecodeError:
            return None

    def _run_vanilla(
        self,
        repo: Path,
        instruction: str,
        base_sha: str,
    ) -> tuple[int, dict[str, Any] | None]:
        environment = os.environ.copy()
        environment["LIONCLAW_HOME"] = str(self.lionclaw_home)
        environment.setdefault("TERM", "xterm-256color")

        command = [
            str(self.lionclaw_bin),
            "run",
            self.runtime,
            "--repo",
            str(repo),
        ]
        (self.logs_dir / "vanilla-command.json").write_text(
            json.dumps(
                {
                    "argv": command,
                    "cwd": str(repo),
                    "lionclaw_home": str(self.lionclaw_home),
                    "runtime": self.runtime,
                    "base_sha": base_sha,
                    "instruction_sha256": hashlib.sha256(
                        instruction.encode()
                    ).hexdigest(),
                },
                indent=2,
            )
            + "\n"
        )

        master_fd, slave_fd = pty.openpty()
        fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, struct.pack("HHHH", 48, 160, 0, 0))
        process = subprocess.Popen(
            command,
            cwd=repo,
            env=environment,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            start_new_session=True,
            close_fds=True,
        )
        os.close(slave_fd)

        output_path = self.logs_dir / "lionclaw-run.pty.raw"
        stop_reader = threading.Event()
        saw_output = threading.Event()

        def read_pty() -> None:
            with output_path.open("wb") as output:
                while not stop_reader.is_set():
                    try:
                        ready, _, _ = select.select([master_fd], [], [], 0.25)
                    except (OSError, ValueError):
                        break
                    if not ready:
                        if process.poll() is not None:
                            break
                        continue
                    try:
                        data = os.read(master_fd, 65536)
                    except OSError:
                        break
                    if not data:
                        break
                    output.write(data)
                    output.flush()
                    saw_output.set()

        reader = threading.Thread(target=read_pty, name="lionclaw-pty-reader", daemon=True)
        reader.start()

        def terminal_output() -> bytes:
            return output_path.read_bytes() if output_path.exists() else b""

        def normalized_terminal_output(output: bytes) -> bytes:
            return b"".join(ANSI_ESCAPE.sub(b"", output).split())

        def wait_for_terminal_text(
            needle: bytes, minimum_size: int, timeout: float
        ) -> bytes:
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline and process.poll() is None:
                output = terminal_output()
                if len(output) >= minimum_size and needle in normalized_terminal_output(output):
                    return output
                time.sleep(0.1)
            return terminal_output()

        def wait_for_terminal_output(
            needle: bytes, offset: int, timeout: float
        ) -> bytes:
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline and process.poll() is None:
                output = terminal_output()
                if needle in output[offset:]:
                    return output
                time.sleep(0.1)
            return terminal_output()

        def wait_for_terminal_quiet(
            minimum_size: int, timeout: float, quiet_secs: float = 1.0
        ) -> bytes:
            deadline = time.monotonic() + timeout
            last_size = -1
            quiet_since: float | None = None
            while time.monotonic() < deadline and process.poll() is None:
                size = len(terminal_output())
                now = time.monotonic()
                if size >= minimum_size:
                    if size != last_size:
                        last_size = size
                        quiet_since = now
                    elif quiet_since is not None and now - quiet_since >= quiet_secs:
                        return terminal_output()
                time.sleep(0.1)
            return terminal_output()

        startup_output = wait_for_terminal_quiet(1, self.startup_wait_secs)
        if process.poll() is not None:
            stop_reader.set()
            reader.join(timeout=5)
            os.close(master_fd)
            raise RuntimeError(
                f"vanilla LionClaw exited {process.returncode} before accepting the official instruction"
            )
        trust_needle = b"Doyoutrustthecontentsofthisdirectory?"
        startup_text = normalized_terminal_output(startup_output)
        if trust_needle in startup_text:
            self._write_all(master_fd, b"\r")
        bootstrap_needle = b"UsetheinstalledLionClawskill."
        bootstrap_prompt = wait_for_terminal_text(
            bootstrap_needle,
            len(startup_output) + 1 if trust_needle in startup_text else 1,
            self.bootstrap_wait_secs,
        )
        if (
            bootstrap_needle not in normalized_terminal_output(bootstrap_prompt)
            or process.poll() is not None
        ):
            raise RuntimeError("vanilla LionClaw did not reach its neutral bootstrap turn")
        assistant_output = wait_for_terminal_output(
            "\u2022".encode(),
            0,
            self.bootstrap_wait_secs,
        )
        if "\u2022".encode() not in assistant_output:
            raise RuntimeError("vanilla LionClaw did not complete its neutral bootstrap turn")
        wait_for_terminal_quiet(
            len(assistant_output) + 1,
            self.bootstrap_wait_secs,
            quiet_secs=10.0,
        )

        # Preserve the exact instruction Harbor supplied. Bracketed paste keeps
        # embedded newlines inside one ordinary terminal submission.
        payload = b"\x1b[200~" + instruction.encode() + b"\x1b[201~\r"
        self._write_all(master_fd, payload)

        snapshots: list[dict[str, Any]] = []
        last_snapshot_digest: str | None = None
        final_report: dict[str, Any] | None = None
        started = time.monotonic()
        exit_requested = False

        while process.poll() is None:
            report = self._report(repo, environment)
            if report is not None:
                final_report = report
                encoded = json.dumps(report, sort_keys=True).encode()
                digest = hashlib.sha256(encoded).hexdigest()
                if digest != last_snapshot_digest:
                    snapshots.append(report)
                    last_snapshot_digest = digest
                    (self.logs_dir / "mission-report.latest.json").write_bytes(
                        json.dumps(report, indent=2, sort_keys=True).encode() + b"\n"
                    )
                if (report.get("finish") is not None or report.get("terminal") is not None) and not exit_requested:
                    self._write_all(master_fd, b"\x04")
                    exit_requested = True
            if time.monotonic() - started >= self.max_secs:
                os.killpg(process.pid, signal.SIGINT)
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=30)
                break
            time.sleep(self.poll_secs)

        stop_reader.set()
        reader.join(timeout=10)
        try:
            os.close(master_fd)
        except OSError:
            pass

        if final_report is None:
            final_report = self._report(repo, environment)
        (self.logs_dir / "mission-report-snapshots.json").write_text(
            json.dumps(snapshots, indent=2, sort_keys=True) + "\n"
        )
        if final_report is not None:
            (self.logs_dir / "mission-report.final.json").write_text(
                json.dumps(final_report, indent=2, sort_keys=True) + "\n"
            )
        return process.returncode if process.returncode is not None else -1, final_report

    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        workspace = self.logs_dir / "workspace"
        workspace.mkdir(parents=True, exist_ok=False)
        await environment.download_dir("/app", workspace)

        supplied_instruction = instruction.encode()
        environment_instruction = (workspace / "instruction.md").read_bytes()
        harbor_instruction_sha256 = hashlib.sha256(supplied_instruction).hexdigest()
        instruction_record = {
            "official_instruction_sha256": self.official_instruction_sha256,
            "harbor_instruction_sha256": harbor_instruction_sha256,
            "environment_instruction_sha256": hashlib.sha256(
                environment_instruction
            ).hexdigest(),
            "harbor_matches_official": (
                harbor_instruction_sha256 == self.official_instruction_sha256
            ),
        }
        (self.logs_dir / "instruction-identity.json").write_text(
            json.dumps(instruction_record, indent=2) + "\n"
        )
        if not instruction_record["harbor_matches_official"]:
            raise RuntimeError("Harbor instruction does not match the pinned official task")
        # Keep the repository-visible instruction identical to Harbor's official
        # task instruction; the upstream environment image omits its scoring appendix.
        (workspace / "instruction.md").write_bytes(supplied_instruction)

        base_sha = self._initialize_repo(workspace)
        exit_code, report = await asyncio.to_thread(
            self._run_vanilla,
            workspace,
            instruction,
            base_sha,
        )

        candidate_root = workspace
        deliverable_sha = None
        mission_id = None
        finish = None
        if report is not None:
            deliverable_sha = report.get("deliverable_head") or report.get("current_sha")
            mission_id = report.get("mission_id")
            finish = report.get("finish")
            if deliverable_sha and deliverable_sha != self._git(workspace, "rev-parse", "HEAD"):
                candidate_root = self.logs_dir / "deliverable"
                self._git(
                    workspace,
                    "worktree",
                    "add",
                    "--detach",
                    str(candidate_root),
                    deliverable_sha,
                )

        candidate = candidate_root / "type-checker"
        if not candidate.is_dir():
            raise RuntimeError(f"LionClaw produced no type-checker candidate at {candidate}")
        await environment.upload_dir(candidate, "/app/type-checker")

        context.metadata = {
            "lionclaw_command": "lionclaw run codex",
            "lionclaw_exit_code": exit_code,
            "lionclaw_mission_id": mission_id,
            "lionclaw_finish": finish,
            "lionclaw_deliverable_head": deliverable_sha,
            "lionclaw_base_sha": base_sha,
            "official_instruction_sha256": instruction_record[
                "harbor_instruction_sha256"
            ],
        }
